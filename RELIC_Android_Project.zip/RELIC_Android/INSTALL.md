# 설치 메모

이 환경에는 Android SDK가 없어 APK를 여기서 직접 빌드 검증할 수는 없었습니다. 프로젝트는 Android Studio에서 열어 Sync/Build하도록 구성되어 있습니다.

권장 설정:
- Gradle JDK: 17
- Gradle: 9.4.1
- Android SDK Platform 37 / Build Tools 36.0.0 이상

Android Studio가 Gradle Wrapper를 요구하면 `gradle wrapper --gradle-version 9.4.1`을 한 번 실행해 wrapper를 생성하면 됩니다.
