# RE:LIC 0.3.0 — Rift Combat + Codex Layout Overhaul

## What changed

### Codex layout
- Replaced the long single-column cards with a clean 2-column gallery.
- Item art gets the majority of each card; long lore is removed from the browsing view.
- Tap any relic to open a large detail sheet.
- Search by name, lineage, form, core, or serial.
- Filter by discovered / undiscovered, rarity, and lineage.
- Sort by codex number, rarity, or name.
- Fusion and battle loadout selection also use the same compact 2-column visual language.

### Rift combat
- 10 fully described zones.
- 4 encounters per zone (3 standard anomalies + 1 boss): 40 total.
- Sequential progression and zone unlocking.
- 3-relic loadouts.
- Enemy weakness tags affect relic battle power.
- Turn system: Stable Strike / Resonance Release / Overload.
- Resonance charges, player stability, enemy HP, battle log, rewards.
- Echo Fragments currency and persistent zone progress.

### 2x2 widget
- The widget now prioritizes the currently active rift and enemy.
- One-tap entry to Rift Combat.
- Shows Echo Fragments, anomaly context, and transmutation shortcut where space allows.

## Version
- versionCode: 3
- versionName: 0.3.0
