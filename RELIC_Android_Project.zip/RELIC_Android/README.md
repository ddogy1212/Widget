# RE:LIC — 현실 연성 수집 게임 + 2×2 Android 위젯

개인용 Android 프로토타입. 현실의 물건을 카메라로 촬영하면 온디바이스 이미지 라벨링과 색 분석으로 3개의 에센스를 추출하고, 선택한 에센스·오늘의 이상현상·확률표를 바탕으로 유물을 호출합니다.

## 포함된 기능
- **정규 도감 1000종**: 이름/시리얼/등급/계보/형태/핵/설명/특성 전부 개별 데이터
- **1000개 개별 WebP 유물 아트**: 10개 계보 × 10개 형태 × 10개 핵 조합, 각 파일 고유
- 등급: `NORMAL → ODD → RARE → ANOMALOUS → RELIC → FORBIDDEN → ???`
- **현실 물건 촬영 → 에센스 3개 추출**
- **일일 이상현상 36종** 및 공명 보정
- 같은 물건을 찍어도 매번 다른 결과가 가능한 랜덤 연성
- **도감 1000칸** / 발견만 보기 / 등급 필터 / 잠긴 기록
- 유물 카드에 **호출 원본 사진 저장**
- **3중 합성**
- **봉인식(비밀 레시피) 42개**: 정확한 3개 조합일 때 고등급 결과 우선
- 10개 연구 구역 계보를 가진 세계관
- **2×2 홈 화면 위젯**
  - 오늘의 이상현상
  - 최신 유물 아트
  - 연성 에너지
  - 도감 진행도
  - `연성` 바로가기
  - 공간이 충분한 2×2 런처에서는 `도감` 버튼 추가
  - 앱 상태 변경 시 즉시 갱신 + 최대 시간당 1회 시스템 갱신

## 위젯 크기
`targetCellWidth=2`, `targetCellHeight=2`로 2×2를 목표로 하며, 런처마다 실제 dp 크기가 달라서 Glance `SizeMode.Responsive`로 110 / 150 / 180dp 레이아웃을 제공합니다.

## 빌드 기준
- Android Studio Quail 계열 권장
- Android Gradle Plugin 9.2.0
- Gradle 9.4.1
- JDK 17
- compileSdk / targetSdk 37
- minSdk 23
- Compose BOM 2026.06.00
- Jetpack Glance 1.2.0
- Activity 1.13.0
- Lifecycle 2.11.0
- Core 1.19.0
- ML Kit image-labeling 17.0.9 (번들형, 최초 실행부터 사용 가능)

## 실행
1. Android Studio에서 `RELIC_Android` 폴더를 엽니다.
2. Gradle 9.4.1 / JDK 17을 사용해 Sync 합니다.
3. Android 기기에 실행합니다.
4. 홈 화면 빈 곳 길게 누르기 → 위젯 → **RE:LIC** → 2×2 배치.

## 데이터 위치
- `app/src/main/assets/relics.json` — 1000개 유물 데이터
- `app/src/main/assets/relic_art/` — 1000개 아트
- `app/src/main/assets/anomalies.json` — 36개 이상현상
- `app/src/main/assets/secret_recipes.json` — 42개 봉인식

## 참고
이 버전의 랜덤 연성은 **현금·결제·교환 기능이 없는 개인용 게임 내 수집 시스템**입니다.
