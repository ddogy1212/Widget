package com.relic.alchemy

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.lifecycleScope
import com.relic.alchemy.widget.RelicWidget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RelicApp() }
    }

    @Composable
    private fun RelicApp() {
        var tab by remember { mutableIntStateOf(intent.getIntExtra("tab", 0).coerceIn(0, 4)) }
        var refresh by remember { mutableIntStateOf(0) }
        val bg = Color(0xFF080A10)
        val fg = Color(0xFFF1F4FA)
        val accent = Color(0xFFA878FF)

        MaterialTheme(
            colorScheme = darkColorScheme(
                background = bg,
                surface = Color(0xFF111522),
                primary = accent,
                onBackground = fg,
                onSurface = fg
            )
        ) {
            Scaffold(
                bottomBar = {
                    NavigationBar(containerColor = Color(0xFF0D1018)) {
                        val labels = listOf("균열", "연성", "도감", "합성", "기록")
                        val icons = listOf("◎", "◈", "▦", "△", "≡")
                        labels.forEachIndexed { i, label ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i },
                                icon = { Text(icons[i]) },
                                label = { Text(label, fontSize = 10.sp) }
                            )
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.fillMaxSize().padding(pad).background(bg)) {
                    when (tab) {
                        0 -> RiftScreen(refresh) { refresh++ }
                        1 -> TransmuteScreen(refresh) { refresh++ }
                        2 -> CodexScreen(refresh)
                        3 -> FusionScreen(refresh) { refresh++ }
                        else -> RecordsScreen(refresh)
                    }
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // RIFT / BATTLE
    // ─────────────────────────────────────────────────────────────────────

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun RiftScreen(refresh: Int, onChanged: () -> Unit) {
        val zones = remember { RelicRepository.zones() }
        val discovered = remember(refresh) { RelicRepository.discoveredIds(this) }
        val owned = remember(discovered) { RelicRepository.relics(this).filter { it.id in discovered } }
        val unlocked = remember(refresh) { RelicRepository.unlockedZone(this) }
        var selectedZoneId by remember(refresh) { mutableIntStateOf(unlocked) }
        val zone = zones.first { it.id == selectedZoneId }
        val progress = remember(refresh, selectedZoneId) { RelicRepository.zoneProgress(this, selectedZoneId) }
        var selectedEnemy by remember(selectedZoneId, refresh) {
            mutableStateOf(zone.enemies[(progress.coerceAtMost(3))])
        }
        var loadout by remember { mutableStateOf<List<Relic>>(emptyList()) }
        var showLoadout by remember { mutableStateOf(false) }
        var battle by remember { mutableStateOf<BattleSession?>(null) }

        if (showLoadout) {
            ModalBottomSheet(
                onDismissRequest = { showLoadout = false },
                containerColor = Color(0xFF0D111B)
            ) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 22.dp)) {
                    Text("전투 유물 편성", fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("최대 3개 · 적의 약점 태그가 있는 유물은 공격력이 크게 상승", color = Color(0xFF9DA8B9), fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    if (owned.isEmpty()) {
                        EmptyPanel("아직 발견한 유물이 없습니다", "연성 탭에서 유물부터 호출하세요.")
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            modifier = Modifier.fillMaxWidth().heightIn(min = 260.dp, max = 560.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 16.dp)
                        ) {
                            gridItems(owned, key = { it.id }) { relic ->
                                CompactRelicTile(
                                    relic = relic,
                                    selected = loadout.any { it.id == relic.id },
                                    subtitle = "전투력 ${RelicRepository.battlePower(relic, selectedEnemy)}",
                                    onClick = {
                                        val exists = loadout.any { it.id == relic.id }
                                        loadout = when {
                                            exists -> loadout.filterNot { it.id == relic.id }
                                            loadout.size < 3 -> loadout + relic
                                            else -> loadout
                                        }
                                    }
                                )
                            }
                        }
                    }
                    Button(
                        onClick = { showLoadout = false },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = loadout.size == 3
                    ) { Text("편성 완료 ${loadout.size}/3") }
                }
            }
        }

        battle?.let { session ->
            BattleView(
                session = session,
                onAction = { action ->
                    val updated = RelicRepository.battleTurn(this, session, action)
                    battle = updated
                    if (updated.finished && updated.victory) {
                        onChanged()
                        lifecycleScope.launch { RelicWidget().updateAll(this@MainActivity) }
                    }
                },
                onExit = { battle = null }
            )
            return
        }

        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("균열 작전", fontSize = 28.sp, fontWeight = FontWeight.Black)
                        Text("10개 구역 · 40개 이상체", color = Color(0xFF98A4B7))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("잔향 파편", fontSize = 10.sp, color = Color(0xFF8B96AA))
                        Text("${RelicRepository.fragments(this@MainActivity)} ◇", color = Color(0xFFFFC76B), fontWeight = FontWeight.Bold)
                    }
                }
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    items(zones, key = { it.id }) { z ->
                        val isUnlocked = z.id <= unlocked
                        val isSelected = z.id == selectedZoneId
                        Card(
                            modifier = Modifier.width(118.dp).clickable(enabled = isUnlocked) {
                                selectedZoneId = z.id
                                val zp = RelicRepository.zoneProgress(this@MainActivity, z.id)
                                selectedEnemy = z.enemies[zp.coerceAtMost(3)]
                                battle = null
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = when {
                                    isSelected -> Color(0xFF292040)
                                    isUnlocked -> Color(0xFF131925)
                                    else -> Color(0xFF0C0F16)
                                }
                            )
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text(z.code, color = if (isUnlocked) Color(0xFFA878FF) else Color(0xFF4E5664), fontWeight = FontWeight.Black)
                                Spacer(Modifier.height(5.dp))
                                Text(if (isUnlocked) z.name else "잠긴 구역", fontWeight = FontWeight.Bold, maxLines = 2, minLines = 2, fontSize = 13.sp)
                                Text(
                                    if (isUnlocked) "${RelicRepository.zoneProgress(this@MainActivity, z.id)}/4 안정화" else "LOCKED",
                                    color = Color(0xFF8994A7), fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }

            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF121723))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(zone.code, color = Color(0xFFA878FF), fontWeight = FontWeight.Black)
                        Text(zone.name, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                        Text(zone.subtitle, color = Color(0xFFE0E4EC), fontWeight = FontWeight.SemiBold)
                        Text(zone.description, color = Color(0xFFB0B9C8), lineHeight = 19.sp, fontSize = 13.sp)
                        HorizontalDivider(color = Color(0xFF2B3242))
                        Text(zone.atmosphere, color = Color(0xFF8FA0B9), fontSize = 12.sp)
                        Text("전술 정보  ${zone.hazard}", color = Color(0xFFFFC76B), fontSize = 12.sp)
                    }
                }
            }

            item { SectionTitle("이상체 신호", "현재 진행 ${progress.coerceAtMost(4)} / 4") }

            items(zone.enemies, key = { it.id }) { enemy ->
                val accessible = enemy.order <= (progress + 1).coerceAtMost(4) || progress >= 4
                val cleared = enemy.order <= progress
                EnemyRow(
                    enemy = enemy,
                    selected = selectedEnemy.id == enemy.id,
                    accessible = accessible,
                    cleared = cleared,
                    onClick = { if (accessible) selectedEnemy = enemy }
                )
            }

            item { SectionTitle("유물 편성", "약점 ${selectedEnemy.weakTags.joinToString(" · ")}") }

            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111522))) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            repeat(3) { index ->
                                val r = loadout.getOrNull(index)
                                Box(
                                    Modifier.weight(1f).height(96.dp)
                                        .background(Color(0xFF171D29), RoundedCornerShape(14.dp))
                                        .border(1.dp, if (r != null) rarityColor(r.rarity) else Color(0xFF2A3241), RoundedCornerShape(14.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (r != null) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Image(RelicRepository.bitmap(this@MainActivity, r).asImageBitmap(), null, Modifier.size(58.dp), contentScale = ContentScale.Fit)
                                            Text(r.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp))
                                        }
                                    } else Text("+", fontSize = 24.sp, color = Color(0xFF687386))
                                }
                            }
                        }
                        OutlinedButton(onClick = { showLoadout = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (loadout.size == 3) "편성 바꾸기" else "유물 3개 선택 ${loadout.size}/3")
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = { battle = RelicRepository.startBattle(this@MainActivity, zone, selectedEnemy, loadout) },
                    enabled = loadout.size == 3 && (selectedEnemy.order <= (progress + 1).coerceAtMost(4) || progress >= 4),
                    modifier = Modifier.fillMaxWidth().height(58.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (selectedEnemy.boss) Color(0xFFB43A58) else Color(0xFF7250CF))
                ) {
                    Text(if (selectedEnemy.boss) "⚠ 핵심체 진입" else "균열 진입", fontWeight = FontWeight.Black, fontSize = 16.sp)
                }
            }
        }
    }

    @Composable
    private fun EnemyRow(enemy: RiftEnemy, selected: Boolean, accessible: Boolean, cleared: Boolean, onClick: () -> Unit) {
        Card(
            modifier = Modifier.fillMaxWidth().clickable(enabled = accessible, onClick = onClick),
            colors = CardDefaults.cardColors(
                containerColor = when {
                    selected -> Color(0xFF282039)
                    accessible -> Color(0xFF121722)
                    else -> Color(0xFF0C0F15)
                }
            )
        ) {
            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).background(
                        when {
                            cleared -> Color(0xFF18342E)
                            enemy.boss -> Color(0xFF351720)
                            else -> Color(0xFF1A2030)
                        }, RoundedCornerShape(14.dp)
                    ), contentAlignment = Alignment.Center
                ) {
                    Text(if (cleared) "✓" else if (enemy.boss) "◆" else "${enemy.order}", color = if (accessible) Color.White else Color(0xFF4B5360), fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (accessible) enemy.name else "미확인 신호", fontWeight = FontWeight.Bold)
                    Text(if (accessible) enemy.title else "앞선 신호를 안정화해야 합니다", color = Color(0xFF8F9AAD), fontSize = 11.sp)
                    if (accessible) Text("HP ${enemy.hp} · 보상 ${enemy.reward}◇", color = Color(0xFF78879E), fontSize = 10.sp)
                }
                if (selected) Text("선택", color = Color(0xFFA878FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    @Composable
    private fun BattleView(session: BattleSession, onAction: (String) -> Unit, onExit: () -> Unit) {
        val enemy = session.enemy
        val loadout = remember(session.loadoutIds) {
            val all = RelicRepository.relics(this).associateBy { it.id }
            session.loadoutIds.mapNotNull { all[it] }
        }
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("RIFT ${session.zoneId.toString().padStart(2,'0')}", color = Color(0xFFFF6E8E), fontWeight = FontWeight.Black)
                Text(enemy.name, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text(enemy.description, color = Color(0xFFABB5C5), fontSize = 13.sp)
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF131722))) {
                    Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        HpBar("이상체", session.enemyHp, session.enemyMaxHp, Color(0xFFFF657F))
                        HpBar("연결 안정도", session.playerHp, session.playerMaxHp, Color(0xFF73C6FF))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("TURN ${session.turn}", color = Color(0xFF8D99AD), fontWeight = FontWeight.Bold)
                            Text("공명 ${"●".repeat(session.resonance)}${"○".repeat(3-session.resonance)}", color = Color(0xFFA878FF))
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    loadout.forEach { r ->
                        Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFF111622))) {
                            Column(Modifier.padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Image(RelicRepository.bitmap(this@MainActivity, r).asImageBitmap(), null, Modifier.fillMaxWidth().aspectRatio(1f), contentScale = ContentScale.Fit)
                                Text(r.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 9.sp)
                                Text("PWR ${RelicRepository.battlePower(r, enemy)}", color = rarityColor(r.rarity), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0E121B))) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("전투 로그", fontWeight = FontWeight.Bold, color = Color(0xFFB7C2D4))
                        session.log.forEach { Text("› $it", fontSize = 11.sp, color = Color(0xFF8E9AAF)) }
                    }
                }
            }
            if (!session.finished) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Button(onClick = { onAction("STRIKE") }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                            Text("안정 타격  ·  공명 충전", fontWeight = FontWeight.Bold)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            OutlinedButton(onClick = { onAction("RESONATE") }, modifier = Modifier.weight(1f).height(50.dp), enabled = session.resonance > 0) {
                                Text("공명 방출")
                            }
                            OutlinedButton(onClick = { onAction("OVERLOAD") }, modifier = Modifier.weight(1f).height(50.dp)) {
                                Text("과부하")
                            }
                        }
                    }
                }
            } else {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = if (session.victory) Color(0xFF123025) else Color(0xFF30151D))) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (session.victory) "균열 안정화" else "연결 종료", fontSize = 23.sp, fontWeight = FontWeight.Black)
                            Text(
                                if (session.victory) "잔향 파편 +${session.enemy.reward} · 다음 신호가 해금될 수 있습니다." else "유물은 손실되지 않습니다. 편성을 바꿔 다시 도전하세요.",
                                color = Color(0xFFB9C2CF), fontSize = 12.sp
                            )
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = onExit, modifier = Modifier.fillMaxWidth()) { Text("작전 화면으로") }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun HpBar(label: String, current: Int, max: Int, color: Color) {
        val fraction = (current.toFloat() / max.toFloat()).coerceIn(0f, 1f)
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(label, fontSize = 11.sp, color = Color(0xFF9CA7B8))
                Text("$current / $max", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Box(Modifier.fillMaxWidth().height(9.dp).background(Color(0xFF262D3B), RoundedCornerShape(20.dp))) {
                Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().background(color, RoundedCornerShape(20.dp)))
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // TRANSMUTE
    // ─────────────────────────────────────────────────────────────────────

    @Composable
    private fun TransmuteScreen(refresh: Int, onChanged: () -> Unit) {
        val anomaly = remember(refresh) { RelicRepository.todayAnomaly(this) }
        var essences by remember { mutableStateOf<List<Essence>>(emptyList()) }
        var result by remember { mutableStateOf<Relic?>(null) }
        var status by remember { mutableStateOf("현실 물건을 촬영해 에센스를 추출하세요") }
        var photoUri by remember { mutableStateOf<Uri?>(null) }

        fun createUri(): Uri {
            val dir = File(cacheDir, "images").apply { mkdirs() }
            val f = File(dir, "capture_${System.currentTimeMillis()}.jpg")
            return FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        }

        val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok && photoUri != null) {
                status = "물성을 읽는 중…"
                lifecycleScope.launch {
                    val e = withContext(Dispatchers.IO) {
                        RelicRepository.extractEssences(this@MainActivity, photoUri!!)
                    }
                    essences = e
                    status = "에센스 하나를 선택하세요"
                }
            }
        }

        LazyColumn(
            Modifier.fillMaxSize().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 20.dp)
        ) {
            item {
                Text("RE:LIC", fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text("현실 연성 기록소", color = Color(0xFF9EA7B8))
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF151A27))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("오늘의 이상현상", color = Color(0xFFA878FF), fontWeight = FontWeight.Bold)
                        Text(anomaly.name, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        Text(anomaly.description, color = Color(0xFFB8C0D0))
                        Text("공명 계수 ×${"%.2f".format(anomaly.multiplier)}", color = Color(0xFFFFC76B), fontSize = 12.sp)
                    }
                }
            }
            item {
                Button(
                    onClick = { photoUri = createUri(); camera.launch(photoUri!!) },
                    modifier = Modifier.fillMaxWidth().height(58.dp)
                ) { Text("◉ 현실 물건 채집", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            }
            item { Text(status, color = Color(0xFFB9C0CE)) }
            if (essences.isNotEmpty()) {
                item {
                    Text("추출된 에센스", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(essences) { e ->
                            Card(
                                Modifier.width(124.dp).clickable {
                                    if (RelicRepository.energy(this@MainActivity) <= 0) {
                                        status = "오늘의 연성 에너지를 모두 사용했습니다"
                                        return@clickable
                                    }
                                    val r = RelicRepository.transmute(this@MainActivity, e)
                                    RelicRepository.spendEnergy(this@MainActivity)
                                    RelicRepository.discover(this@MainActivity, r, photoUri)
                                    result = r
                                    status = "${e.label} 에센스가 ${r.name}을 호출했습니다"
                                    onChanged()
                                    lifecycleScope.launch { RelicWidget().updateAll(this@MainActivity) }
                                },
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2030))
                            ) {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(e.label, fontWeight = FontWeight.Bold)
                                    Text(e.source, maxLines = 2, fontSize = 11.sp, color = Color(0xFF9DA8BB))
                                    Text("연성", color = Color(0xFFA878FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
            item { Text("연성 에너지 ${RelicRepository.energy(this@MainActivity)}/3", fontWeight = FontWeight.Bold) }
            result?.let { r -> item { RelicDetailCard(r, showSource = true) } }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // CODEX - layout overhaul
    // ─────────────────────────────────────────────────────────────────────

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun CodexScreen(refresh: Int) {
        val discovered = remember(refresh) { RelicRepository.discoveredIds(this) }
        val all = remember { RelicRepository.relics(this) }
        val lineages = remember { all.map { it.lineage }.distinct() }
        var query by remember { mutableStateOf("") }
        var statusFilter by remember { mutableStateOf("ALL") }
        var rarityFilter by remember { mutableStateOf("ALL") }
        var lineageFilter by remember { mutableStateOf("ALL") }
        var sortMode by remember { mutableStateOf("ID") }
        var showFilters by remember { mutableStateOf(false) }
        var selectedRelic by remember { mutableStateOf<Relic?>(null) }

        val visible = remember(query, statusFilter, rarityFilter, lineageFilter, sortMode, discovered) {
            all.asSequence().filter { r ->
                val q = query.trim().lowercase()
                val matchQuery = q.isBlank() || listOf(r.name, r.lineage, r.form, r.core, r.serial).any { it.lowercase().contains(q) }
                val matchStatus = when (statusFilter) {
                    "FOUND" -> r.id in discovered
                    "LOCKED" -> r.id !in discovered
                    else -> true
                }
                val matchRarity = rarityFilter == "ALL" || r.rarity == rarityFilter
                val matchLineage = lineageFilter == "ALL" || r.lineage == lineageFilter
                matchQuery && matchStatus && matchRarity && matchLineage
            }.toList().let { list ->
                when (sortMode) {
                    "RARITY" -> list.sortedWith(compareByDescending<Relic> { RelicRepository.rarityScore(it.rarity) }.thenBy { it.id })
                    "NAME" -> list.sortedBy { it.name }
                    else -> list.sortedBy { it.id }
                }
            }
        }

        if (showFilters) {
            ModalBottomSheet(onDismissRequest = { showFilters = false }, containerColor = Color(0xFF0D111B)) {
                LazyColumn(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(bottom = 28.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item { Text("도감 필터", fontSize = 23.sp, fontWeight = FontWeight.Black) }
                    item {
                        Text("발견 상태", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(7.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(listOf("ALL" to "전체", "FOUND" to "발견", "LOCKED" to "미발견")) { (v, label) ->
                                FilterChip(selected = statusFilter == v, onClick = { statusFilter = v }, label = { Text(label) })
                            }
                        }
                    }
                    item {
                        Text("등급", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(7.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(listOf("ALL", "NORMAL", "ODD", "RARE", "ANOMALOUS", "RELIC", "FORBIDDEN", "???")) { v ->
                                FilterChip(selected = rarityFilter == v, onClick = { rarityFilter = v }, label = { Text(if (v == "ALL") "전체" else v) })
                            }
                        }
                    }
                    item {
                        Text("계보", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(7.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(listOf("ALL") + lineages) { v ->
                                FilterChip(selected = lineageFilter == v, onClick = { lineageFilter = v }, label = { Text(if (v == "ALL") "전체" else v) })
                            }
                        }
                    }
                    item {
                        Text("정렬", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(7.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(listOf("ID" to "도감 번호", "RARITY" to "희귀도", "NAME" to "이름")) { (v, label) ->
                                FilterChip(selected = sortMode == v, onClick = { sortMode = v }, label = { Text(label) })
                            }
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    statusFilter = "ALL"; rarityFilter = "ALL"; lineageFilter = "ALL"; sortMode = "ID"
                                }, modifier = Modifier.weight(1f)
                            ) { Text("초기화") }
                            Button(onClick = { showFilters = false }, modifier = Modifier.weight(1f)) { Text("적용") }
                        }
                    }
                }
            }
        }

        selectedRelic?.let { r ->
            RelicDetailSheet(relic = r, discovered = r.id in discovered, onDismiss = { selectedRelic = null })
        }

        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("도감", fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Text("발견 ${discovered.size} / 1000", color = Color(0xFFA878FF), fontWeight = FontWeight.Bold)
                }
                Text("${visible.size}개 표시", color = Color(0xFF7F8B9F), fontSize = 11.sp)
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    label = { Text("이름 · 형태 · 코어 검색") },
                    leadingIcon = { Text("⌕") }
                )
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { showFilters = true }, modifier = Modifier.height(56.dp)) { Text("필터") }
            }
            Spacer(Modifier.height(8.dp))
            val active = buildList {
                if (statusFilter != "ALL") add(if (statusFilter == "FOUND") "발견" else "미발견")
                if (rarityFilter != "ALL") add(rarityFilter)
                if (lineageFilter != "ALL") add(lineageFilter)
                if (sortMode != "ID") add(if (sortMode == "RARITY") "희귀도순" else "이름순")
            }
            if (active.isNotEmpty()) {
                Text(active.joinToString("  ·  "), color = Color(0xFF9CA8BA), fontSize = 11.sp, modifier = Modifier.padding(bottom = 8.dp))
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 18.dp)
            ) {
                gridItems(visible, key = { it.id }) { r ->
                    RelicGridCard(
                        relic = r,
                        discovered = r.id in discovered,
                        onClick = { selectedRelic = r }
                    )
                }
            }
        }
    }

    @Composable
    private fun RelicGridCard(relic: Relic, discovered: Boolean, onClick: () -> Unit) {
        val borderColor = if (discovered) rarityColor(relic.rarity) else Color(0xFF242B38)
        Card(
            modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
            colors = CardDefaults.cardColors(containerColor = if (discovered) Color(0xFF111622) else Color(0xFF0D1017)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(8.dp)) {
                Box(
                    Modifier.fillMaxWidth().aspectRatio(1f)
                        .background(Color(0xFF0A0D14), RoundedCornerShape(12.dp))
                        .border(1.dp, borderColor.copy(alpha = if (discovered) 0.75f else 0.5f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (discovered) {
                        Image(
                            RelicRepository.bitmap(this@MainActivity, relic).asImageBitmap(),
                            contentDescription = relic.name,
                            modifier = Modifier.fillMaxSize().padding(6.dp),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (relic.secret) "?" else "◈", fontSize = 30.sp, color = Color(0xFF4B5566), fontWeight = FontWeight.Black)
                            Text("미발견", color = Color(0xFF596477), fontSize = 9.sp)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (discovered) relic.rarity else "LOCKED",
                        color = if (discovered) rarityColor(relic.rarity) else Color(0xFF5C6677),
                        fontSize = 9.sp, fontWeight = FontWeight.Black,
                        modifier = Modifier.weight(1f)
                    )
                    Text(relic.id.toString().padStart(4, '0'), color = Color(0xFF626D80), fontSize = 9.sp)
                }
                Text(
                    if (discovered) relic.name else if (relic.secret) "미확인 기록" else relic.form,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    minLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 13.sp,
                    lineHeight = 16.sp
                )
                Text(
                    if (discovered) "${relic.lineage} · ${relic.core}" else relic.lineage,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = Color(0xFF8793A7), fontSize = 9.sp
                )
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun RelicDetailSheet(relic: Relic, discovered: Boolean, onDismiss: () -> Unit) {
        ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color(0xFF0D111B)) {
            if (!discovered) {
                Column(Modifier.fillMaxWidth().padding(22.dp).padding(bottom = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(170.dp).background(Color(0xFF121722), RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) {
                        Text("?", fontSize = 64.sp, color = Color(0xFF465064), fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(if (relic.secret) "미확인 기록" else "미발견 유물", fontSize = 24.sp, fontWeight = FontWeight.Black)
                    if (!relic.secret) Text("분류: ${relic.lineage} · ${relic.form}", color = Color(0xFF8F9AAF))
                    Text("현실 연성 또는 합성을 통해 기록을 해제하세요.", color = Color(0xFF7F8A9C), fontSize = 12.sp)
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                    contentPadding = PaddingValues(bottom = 30.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Image(
                            RelicRepository.bitmap(this@MainActivity, relic).asImageBitmap(), null,
                            Modifier.fillMaxWidth().height(310.dp), contentScale = ContentScale.Fit
                        )
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(relic.rarity, color = rarityColor(relic.rarity), fontWeight = FontWeight.Black)
                            Spacer(Modifier.width(8.dp))
                            Text(relic.serial, color = Color(0xFF768297), fontSize = 11.sp)
                        }
                        Text(relic.name, fontSize = 25.sp, fontWeight = FontWeight.Black)
                        Text("${relic.lineage}  /  ${relic.form}  /  ${relic.core}", color = Color(0xFF9BA8BC), fontSize = 12.sp)
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF121824))) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Text("기록", color = Color(0xFF8995A8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(relic.description, color = Color(0xFFD1D7E0), lineHeight = 20.sp, fontSize = 13.sp)
                                HorizontalDivider(color = Color(0xFF293142))
                                Text("전투 특성", color = Color(0xFFA878FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(relic.effect, color = Color(0xFFB9C8E0), fontSize = 13.sp)
                            }
                        }
                    }
                    val source = remember(relic.id) { RelicRepository.sourceBitmap(this@MainActivity, relic.id) }
                    if (source != null) {
                        item {
                            Text("호출 원본", fontWeight = FontWeight.Bold, color = Color(0xFFFFC76B))
                            Image(source.asImageBitmap(), null, Modifier.fillMaxWidth().height(180.dp), contentScale = ContentScale.Crop)
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun RelicDetailCard(r: Relic, showSource: Boolean = false) {
        val source = remember(r.id, showSource) { if (showSource) RelicRepository.sourceBitmap(this, r.id) else null }
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111522)), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Image(RelicRepository.bitmap(this@MainActivity, r).asImageBitmap(), null, Modifier.fillMaxWidth().height(290.dp), contentScale = ContentScale.Fit)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(r.rarity, color = rarityColor(r.rarity), fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(8.dp)); Text(r.serial, fontSize = 11.sp, color = Color(0xFF8792A5))
                }
                Text(r.name, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text("${r.lineage} · ${r.form} · ${r.core}", color = Color(0xFFAEB8C8))
                Text(r.description, fontSize = 13.sp, color = Color(0xFFC6CDDA))
                HorizontalDivider(color = Color(0xFF293044))
                Text("특성  ${r.effect}", fontSize = 12.sp, color = Color(0xFF9CC6FF))
                if (source != null) {
                    Text("호출 원본", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFC76B))
                    Image(source.asImageBitmap(), null, Modifier.fillMaxWidth().height(140.dp), contentScale = ContentScale.Crop)
                }
            }
        }
    }

    @Composable
    private fun CompactRelicTile(relic: Relic, selected: Boolean, subtitle: String, onClick: () -> Unit) {
        Card(
            modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
            colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF28203D) else Color(0xFF121722))
        ) {
            Column(Modifier.padding(8.dp)) {
                Box(
                    Modifier.fillMaxWidth().aspectRatio(1f).background(Color(0xFF090C12), RoundedCornerShape(12.dp))
                        .border(1.dp, if (selected) Color(0xFFA878FF) else rarityColor(relic.rarity).copy(alpha = .55f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(RelicRepository.bitmap(this@MainActivity, relic).asImageBitmap(), null, Modifier.fillMaxSize().padding(6.dp), contentScale = ContentScale.Fit)
                    if (selected) {
                        Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp).background(Color(0xFFA878FF), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                            Text("✓", fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(relic.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(subtitle, color = Color(0xFF8F9CAF), fontSize = 9.sp)
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // FUSION
    // ─────────────────────────────────────────────────────────────────────

    @Composable
    private fun FusionScreen(refresh: Int, onChanged: () -> Unit) {
        val discovered = remember(refresh) { RelicRepository.discoveredIds(this) }
        val owned = remember(discovered) { RelicRepository.relics(this).filter { it.id in discovered } }
        var selected by remember { mutableStateOf<List<Relic>>(emptyList()) }
        var outcome by remember { mutableStateOf<FusionOutcome?>(null) }
        val recipes = remember { RelicRepository.recipes(this) }
        val nearHints = remember(selected) {
            if (selected.size < 2) emptyList() else recipes.filter { recipe -> selected.all { it.id in recipe.requires } }.take(3)
        }

        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
            Spacer(Modifier.height(14.dp))
            Text("3중 합성", fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text("아래 그리드에서 유물 3개 선택", color = Color(0xFF97A3B6), fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(3) { index ->
                    val r = selected.getOrNull(index)
                    Box(
                        Modifier.weight(1f).height(94.dp).background(Color(0xFF111622), RoundedCornerShape(14.dp))
                            .border(1.dp, r?.let { rarityColor(it.rarity) } ?: Color(0xFF293142), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (r == null) Text("+", color = Color(0xFF5D687A), fontSize = 24.sp)
                        else Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(RelicRepository.bitmap(this@MainActivity, r).asImageBitmap(), null, Modifier.size(58.dp), contentScale = ContentScale.Fit)
                            Text(r.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp))
                        }
                    }
                }
            }

            if (nearHints.isNotEmpty()) {
                Text("봉인 반응: ${nearHints.joinToString(" / ") { it.hint }}", color = Color(0xFFC076FF), fontSize = 10.sp, modifier = Modifier.padding(vertical = 7.dp))
            } else Spacer(Modifier.height(8.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 10.dp)
            ) {
                gridItems(owned, key = { it.id }) { r ->
                    CompactRelicTile(
                        relic = r,
                        selected = selected.any { it.id == r.id },
                        subtitle = "${r.rarity} · ${r.core}",
                        onClick = {
                            val on = selected.any { it.id == r.id }
                            selected = if (on) selected.filterNot { it.id == r.id } else if (selected.size < 3) selected + r else selected
                        }
                    )
                }
            }
            Button(
                onClick = {
                    if (selected.size == 3) {
                        val f = RelicRepository.fuse(this@MainActivity, selected)
                        RelicRepository.discover(this@MainActivity, f.relic)
                        outcome = f
                        selected = emptyList()
                        onChanged()
                        lifecycleScope.launch { RelicWidget().updateAll(this@MainActivity) }
                    }
                },
                enabled = selected.size == 3,
                modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp).height(52.dp)
            ) { Text("합성 실행 ${selected.size}/3") }
        }

        outcome?.let { f ->
            AlertDialog(
                onDismissRequest = { outcome = null },
                confirmButton = { TextButton(onClick = { outcome = null }) { Text("확인") } },
                title = { Text(f.secretRecipeName ?: "합성 완료") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Image(RelicRepository.bitmap(this@MainActivity, f.relic).asImageBitmap(), null, Modifier.fillMaxWidth().height(180.dp), contentScale = ContentScale.Fit)
                        Text(f.relic.name, fontWeight = FontWeight.Black, fontSize = 18.sp)
                        Text(f.message, color = Color(0xFF9FA9B9), fontSize = 12.sp)
                    }
                }
            )
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // RECORDS / WORLD
    // ─────────────────────────────────────────────────────────────────────

    @Composable
    private fun RecordsScreen(refresh: Int) {
        val zones = remember { RelicRepository.zones() }
        val unlocked = remember(refresh) { RelicRepository.unlockedZone(this) }
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("잔향권 기록", fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text("2049년 이후 사물의 사용 흔적이 물질화되기 시작했다. 열 개 연구구역은 그 흔적을 서로 다른 방식으로 압축했고, RE:LIC은 현실 사물을 관측해 이미 존재하는 유물을 호출한다.", color = Color(0xFFB3BDCB), lineHeight = 20.sp, fontSize = 13.sp)
            }
            item { SectionTitle("구역 기록", "해금 $unlocked / 10") }
            items(zones, key = { it.id }) { z ->
                val open = z.id <= unlocked
                Card(colors = CardDefaults.cardColors(containerColor = if (open) Color(0xFF121722) else Color(0xFF0C0F15))) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(z.code, color = if (open) Color(0xFFA878FF) else Color(0xFF4C5564), fontWeight = FontWeight.Black)
                            Text(if (open) "${RelicRepository.zoneProgress(this@MainActivity, z.id)}/4" else "LOCKED", color = Color(0xFF778397), fontSize = 10.sp)
                        }
                        Text(if (open) z.name else "미확인 구역", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        if (open) {
                            Text(z.subtitle, color = Color(0xFFC4CBD7), fontSize = 12.sp)
                            Text(z.atmosphere, color = Color(0xFF8491A5), fontSize = 11.sp)
                        }
                    }
                }
            }
            item { SectionTitle("등급 체계") }
            item {
                Text(
                    "NORMAL — 안정적인 잔향\nODD — 성질이 한 번 뒤틀린 개체\nRARE — 계보와 핵 결합이 뚜렷한 개체\nANOMALOUS — 환경에 따라 행동이 바뀌는 개체\nRELIC — 연구구역 핵심 기록과 연결된 개체\nFORBIDDEN — 일반 연성표에서 봉인된 개체\n??? — 정규 도감 규칙 밖의 미확인 개체",
                    color = Color(0xFFABB6C7), lineHeight = 21.sp
                )
            }
        }
    }

    @Composable
    private fun SectionTitle(title: String, trailing: String = "") {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            if (trailing.isNotBlank()) Text(trailing, color = Color(0xFF8290A4), fontSize = 10.sp)
        }
    }

    @Composable
    private fun EmptyPanel(title: String, body: String) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF121722))) {
            Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("◇", fontSize = 30.sp, color = Color(0xFF5F6B80))
                Text(title, fontWeight = FontWeight.Bold)
                Text(body, color = Color(0xFF8591A4), fontSize = 11.sp)
            }
        }
    }

    private fun rarityColor(r: String) = when (r) {
        "NORMAL" -> Color(0xFF9CA9BA)
        "ODD" -> Color(0xFF4FCBA7)
        "RARE" -> Color(0xFF5C9BFF)
        "ANOMALOUS" -> Color(0xFFC16AFF)
        "RELIC" -> Color(0xFFFFC15A)
        "FORBIDDEN" -> Color(0xFFFF5C78)
        else -> Color(0xFFF2F4FF)
    }
}
