package com.relic.alchemy

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.lifecycleScope
import com.relic.alchemy.widget.RelicWidget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RelicApp() }
    }

    @Composable
    private fun RelicApp() {
        var tab by remember { mutableIntStateOf(intent.getIntExtra("tab", 0).coerceIn(0, 3)) }
        var refresh by remember { mutableIntStateOf(0) }
        val bg = Color(0xFF080A10)
        val fg = Color(0xFFF1F4FA)
        val accent = Color(0xFFA878FF)

        MaterialTheme(
            colorScheme = darkColorScheme(
                background = bg,
                surface = Color(0xFF111522),
                primary = accent,
                onBackground = fg,
                onSurface = fg
            )
        ) {
            Scaffold(
                bottomBar = {
                    NavigationBar(containerColor = Color(0xFF0D1018)) {
                        val labels = listOf("연성", "도감", "합성", "세계관")
                        val icons = listOf("◈", "▦", "△", "◎")
                        labels.forEachIndexed { i, label ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i },
                                icon = { Text(icons[i]) },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.fillMaxSize().padding(pad).background(bg)) {
                    when (tab) {
                        0 -> TransmuteScreen(refresh) { refresh++ }
                        1 -> CodexScreen(refresh)
                        2 -> FusionScreen(refresh) { refresh++ }
                        else -> LoreScreen()
                    }
                }
            }
        }
    }

    @Composable
    private fun TransmuteScreen(refresh: Int, onChanged: () -> Unit) {
        val anomaly = remember(refresh) { RelicRepository.todayAnomaly(this) }
        var essences by remember { mutableStateOf<List<Essence>>(emptyList()) }
        var result by remember { mutableStateOf<Relic?>(null) }
        var status by remember { mutableStateOf("현실 물건을 촬영해 에센스를 추출하세요") }
        var photoUri by remember { mutableStateOf<Uri?>(null) }

        fun createUri(): Uri {
            val dir = File(cacheDir, "images").apply { mkdirs() }
            val f = File(dir, "capture_${System.currentTimeMillis()}.jpg")
            return FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        }

        val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok && photoUri != null) {
                status = "물성을 읽는 중…"
                lifecycleScope.launch {
                    val e = withContext(Dispatchers.IO) {
                        RelicRepository.extractEssences(this@MainActivity, photoUri!!)
                    }
                    essences = e
                    status = "에센스 하나를 선택하세요"
                }
            }
        }

        LazyColumn(
            Modifier.fillMaxSize().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("RE:LIC", fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text("현실 연성 기록소", color = Color(0xFF9EA7B8))
            }

            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF151A27))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("오늘의 이상현상", color = Color(0xFFA878FF), fontWeight = FontWeight.Bold)
                        Text(anomaly.name, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        Text(anomaly.description, color = Color(0xFFB8C0D0))
                        Text("공명 계수 ×${"%.2f".format(anomaly.multiplier)}", color = Color(0xFFFFC76B), fontSize = 12.sp)
                    }
                }
            }

            item {
                Button(
                    onClick = { photoUri = createUri(); camera.launch(photoUri!!) },
                    modifier = Modifier.fillMaxWidth().height(58.dp)
                ) {
                    Text("◉ 현실 물건 채집", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
            }

            item { Text(status, color = Color(0xFFB9C0CE)) }

            if (essences.isNotEmpty()) {
                item {
                    Text("추출된 에센스", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(essences) { e ->
                            Card(
                                Modifier.width(124.dp).clickable {
                                    if (RelicRepository.energy(this@MainActivity) <= 0) {
                                        status = "오늘의 연성 에너지를 모두 사용했습니다"
                                        return@clickable
                                    }
                                    val r = RelicRepository.transmute(this@MainActivity, e)
                                    RelicRepository.spendEnergy(this@MainActivity)
                                    RelicRepository.discover(this@MainActivity, r, photoUri)
                                    result = r
                                    status = "${e.label} 에센스가 ${r.name}을 호출했습니다"
                                    onChanged()
                                    lifecycleScope.launch { RelicWidget().updateAll(this@MainActivity) }
                                },
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2030))
                            ) {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(e.label, fontWeight = FontWeight.Bold)
                                    Text(e.source, maxLines = 2, fontSize = 11.sp, color = Color(0xFF9DA8BB))
                                    Text("연성", color = Color(0xFFA878FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Text("연성 에너지 ${RelicRepository.energy(this@MainActivity)}/3", fontWeight = FontWeight.Bold)
            }

            result?.let { r -> item { RelicCard(r, large = true, showSource = true) } }
        }
    }

    @Composable
    private fun RelicCard(r: Relic, large: Boolean = false, showSource: Boolean = false) {
        val bm = remember(r.id) { RelicRepository.bitmap(this, r) }
        val source = remember(r.id, showSource) { if (showSource) RelicRepository.sourceBitmap(this, r.id) else null }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111522)),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Image(
                    bm.asImageBitmap(), null,
                    Modifier.fillMaxWidth().height(if (large) 280.dp else 180.dp),
                    contentScale = ContentScale.Fit
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(r.rarity, color = rarityColor(r.rarity), fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(8.dp))
                    Text(r.serial, fontSize = 11.sp, color = Color(0xFF8792A5))
                }
                Text(r.name, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                Text("${r.lineage} · ${r.form} · ${r.core}", color = Color(0xFFAEB8C8))
                Text(r.description, fontSize = 13.sp, color = Color(0xFFC6CDDA))
                HorizontalDivider(color = Color(0xFF293044))
                Text("특성  ${r.effect}", fontSize = 12.sp, color = Color(0xFF9CC6FF))

                if (source != null) {
                    Text("호출 원본", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFC76B))
                    Image(
                        source.asImageBitmap(), null,
                        Modifier.fillMaxWidth().height(140.dp),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }
    }

    @Composable
    private fun LockedRelicCard(r: Relic) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0E121B))) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(58.dp).background(Color(0xFF171C27), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("?", fontSize = 24.sp, color = Color(0xFF5D6678), fontWeight = FontWeight.Black) }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(if (r.secret) "미확인 기록" else "미발견 유물", fontWeight = FontWeight.Bold, color = Color(0xFF7B8598))
                    Text(if (r.secret) "분류 잠김" else "${r.lineage} · ${r.form}", fontSize = 11.sp, color = Color(0xFF596274))
                }
            }
        }
    }

    @Composable
    private fun CodexScreen(refresh: Int) {
        val discovered = remember(refresh) { RelicRepository.discoveredIds(this) }
        val all = remember { RelicRepository.relics(this) }
        var filter by remember { mutableStateOf("ALL") }
        var discoveredOnly by remember { mutableStateOf(false) }

        val visible = remember(filter, discovered, discoveredOnly) {
            all.filter { relic ->
                (filter == "ALL" || relic.rarity == filter) && (!discoveredOnly || relic.id in discovered)
            }
        }

        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text("도감", fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text("발견 ${discovered.size} / 1000", color = Color(0xFFA878FF))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("발견만 보기", fontSize = 12.sp, color = Color(0xFFAAB3C3))
                Spacer(Modifier.width(8.dp))
                Switch(checked = discoveredOnly, onCheckedChange = { discoveredOnly = it })
            }
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                items(listOf("ALL", "NORMAL", "ODD", "RARE", "ANOMALOUS", "RELIC", "FORBIDDEN", "???")) { r ->
                    FilterChip(selected = filter == r, onClick = { filter = r }, label = { Text(r) })
                }
            }
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(visible, key = { it.id }) { r ->
                    if (r.id in discovered) RelicCard(r, showSource = true) else LockedRelicCard(r)
                }
            }
        }
    }

    @Composable
    private fun FusionScreen(refresh: Int, onChanged: () -> Unit) {
        val discovered = remember(refresh) { RelicRepository.discoveredIds(this) }
        val owned = remember(discovered) { RelicRepository.relics(this).filter { it.id in discovered } }
        var selected by remember { mutableStateOf<List<Relic>>(emptyList()) }
        var outcome by remember { mutableStateOf<FusionOutcome?>(null) }
        val recipes = remember { RelicRepository.recipes(this) }
        val nearHints = remember(selected) {
            if (selected.size < 2) emptyList()
            else recipes.filter { recipe -> selected.all { it.id in recipe.requires } }.take(3)
        }

        LazyColumn(
            Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("3중 합성", fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text(
                    "발견한 유물 3개를 골라 계보를 재배열합니다. 정확한 조합 42개는 봉인식으로 연결됩니다.",
                    color = Color(0xFFABB5C5)
                )
            }

            if (nearHints.isNotEmpty()) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF17132A))) {
                        Column(Modifier.padding(12.dp)) {
                            Text("봉인 반응 감지", color = Color(0xFFC076FF), fontWeight = FontWeight.Bold)
                            nearHints.forEach { Text("• ${it.hint}", fontSize = 11.sp, color = Color(0xFFAEB7C8)) }
                        }
                    }
                }
            }

            items(owned, key = { it.id }) { r ->
                val on = selected.any { it.id == r.id }
                Card(
                    Modifier.fillMaxWidth().clickable {
                        selected = if (on) selected.filterNot { it.id == r.id }
                        else if (selected.size < 3) selected + r else selected
                    },
                    colors = CardDefaults.cardColors(
                        containerColor = if (on) Color(0xFF292041) else Color(0xFF121723)
                    )
                ) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(RelicRepository.bitmap(this@MainActivity, r).asImageBitmap(), null, Modifier.size(64.dp))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(r.name, fontWeight = FontWeight.Bold)
                            Text("${r.rarity} · ${r.lineage}", fontSize = 12.sp, color = Color(0xFF9EA9BC))
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        if (selected.size == 3) {
                            val f = RelicRepository.fuse(this@MainActivity, selected)
                            RelicRepository.discover(this@MainActivity, f.relic)
                            outcome = f
                            selected = emptyList()
                            onChanged()
                            lifecycleScope.launch { RelicWidget().updateAll(this@MainActivity) }
                        }
                    },
                    enabled = selected.size == 3,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("합성 실행 ${selected.size}/3") }
            }

            outcome?.let { f ->
                item {
                    if (f.secretRecipeName != null) {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF2B1220))) {
                            Column(Modifier.padding(14.dp)) {
                                Text("⚠ 봉인식 해제", color = Color(0xFFFF6D8B), fontWeight = FontWeight.Black)
                                Text(f.secretRecipeName, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                                Text(f.message, color = Color(0xFFC8B5BE), fontSize = 12.sp)
                            }
                        }
                    } else {
                        Text(f.message, color = Color(0xFF9FB5D6))
                    }
                    Spacer(Modifier.height(10.dp))
                    RelicCard(f.relic, large = true)
                }
            }
        }
    }

    @Composable
    private fun LoreScreen() {
        val lineages = listOf(
            "야상회로 — 빛이 사라진 뒤에도 신호를 보존하던 밤의 공방",
            "녹맥원 — 폐허를 뚫고 자란 식물성 기억망",
            "전하성소 — 정전 직전의 마지막 전류를 봉인한 실험 성소",
            "성간창고 — 대기권 밖 미등록 관측물의 회수 보관소",
            "기록심층 — 사라진 도시의 기록을 물성으로 압축하던 지하 서고",
            "조석궁 — 바닷물의 주기와 감정을 동시에 측정하던 침수 시설",
            "잔화실 — 완전히 꺼지지 않는 열원을 연구하던 붉은 실험실",
            "유리경계 — 현실과 반사면 사이의 오차를 수집하던 관측 구역",
            "기계회랑 — 주인 없이도 수백 년 작동한 자동 수복 회랑",
            "몽상층 — 수면 중 떠오른 형태를 고체로 굳히던 비공식 연구층"
        )
        val grades = listOf(
            "NORMAL — 안정적인 잔향",
            "ODD — 성질이 한 번 뒤틀린 개체",
            "RARE — 계보와 핵의 결합이 뚜렷한 개체",
            "ANOMALOUS — 환경에 따라 행동이 바뀌는 개체",
            "RELIC — 연구 구역 핵심 기록과 연결된 개체",
            "FORBIDDEN — 일반 연성표에서 봉인된 개체",
            "??? — 정규 도감 규칙을 따르지 않는 미확인 개체"
        )

        LazyColumn(
            Modifier.fillMaxSize().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Text("세계관 · 잔향권", fontSize = 28.sp, fontWeight = FontWeight.Black) }
            item {
                Text(
                    "2049년, 세계 곳곳에서 사물의 ‘사용 흔적’이 물리적인 결정처럼 굳는 현상이 시작되었다. 사람들은 그것을 잔향이라 불렀다. 이후 폐쇄된 10개의 연구 구역이 서로 다른 방식으로 잔향을 압축했고, 그 결과가 지금의 유물이다.\n\n" +
                        "RE:LIC 기록소는 유물을 구매하거나 제작하지 않는다. 현실의 평범한 사물을 관찰해 에센스를 추출하고, 이미 존재하지만 보이지 않던 유물을 ‘호출’한다. 같은 물건도 시간·빛·오늘의 이상현상에 따라 다른 결과를 낸다.\n\n" +
                        "도감에는 1000개의 정규 기록이 있다. 다만 ??? 등급은 기록 체계의 빈틈에서 관측되며, 봉인식 42개는 일반 합성 규칙을 무시한다.",
                    color = Color(0xFFC7CEDA), lineHeight = 22.sp
                )
            }
            item { Text("10개 계보", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            items(lineages) { Text(it, color = Color(0xFFB5C0D2)) }
            item { Text("등급", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            items(grades) { Text(it, color = Color(0xFFB5C0D2)) }
        }
    }

    private fun rarityColor(r: String) = when (r) {
        "NORMAL" -> Color(0xFF8793A5)
        "ODD" -> Color(0xFF6AC8AD)
        "RARE" -> Color(0xFF65A5FF)
        "ANOMALOUS" -> Color(0xFFC076FF)
        "RELIC" -> Color(0xFFFFC05A)
        "FORBIDDEN" -> Color(0xFFFF5878)
        else -> Color.White
    }
}
