package com.relic.alchemy

data class Relic(
    val id: Int,
    val serial: String,
    val name: String,
    val rarity: String,
    val rarityKr: String,
    val lineage: String,
    val lineageCode: String,
    val form: String,
    val formCode: String,
    val core: String,
    val coreCode: String,
    val tags: List<String>,
    val description: String,
    val effect: String,
    val art: String,
    val secret: Boolean
)

data class Anomaly(
    val id: Int,
    val name: String,
    val code: String,
    val description: String,
    val boostTag: String,
    val multiplier: Double
)

data class SecretRecipe(
    val id: Int,
    val name: String,
    val requires: List<Int>,
    val result: Int,
    val hint: String
)

data class Essence(val code: String, val label: String, val source: String)

data class FusionOutcome(
    val relic: Relic,
    val secretRecipeName: String? = null,
    val message: String
)

data class RiftEnemy(
    val id: Int,
    val order: Int,
    val name: String,
    val title: String,
    val description: String,
    val weakTags: List<String>,
    val hp: Int,
    val attack: Int,
    val reward: Int,
    val boss: Boolean = false
)

data class RiftZone(
    val id: Int,
    val code: String,
    val name: String,
    val subtitle: String,
    val description: String,
    val atmosphere: String,
    val hazard: String,
    val recommendedTags: List<String>,
    val enemies: List<RiftEnemy>
)

data class BattleSession(
    val zoneId: Int,
    val enemy: RiftEnemy,
    val loadoutIds: List<Int>,
    val playerMaxHp: Int,
    val playerHp: Int,
    val enemyMaxHp: Int,
    val enemyHp: Int,
    val resonance: Int,
    val turn: Int,
    val log: List<String>,
    val finished: Boolean = false,
    val victory: Boolean = false
)
