package com.relic.alchemy

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import androidx.core.content.edit
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.random.Random

object RelicRepository {
    private var relicCache: List<Relic>? = null
    private var anomalyCache: List<Anomaly>? = null
    private var recipeCache: List<SecretRecipe>? = null
    private const val PREF = "relic_state"

    fun relics(context: Context): List<Relic> = relicCache ?: run {
        val a = JSONArray(context.assets.open("relics.json").bufferedReader().use { it.readText() })
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val tags = o.getJSONArray("tags")
                add(
                    Relic(
                        o.getInt("id"), o.getString("serial"), o.getString("name"),
                        o.getString("rarity"), o.getString("rarityKr"),
                        o.getString("lineage"), o.getString("lineageCode"),
                        o.getString("form"), o.getString("formCode"),
                        o.getString("core"), o.getString("coreCode"),
                        List(tags.length()) { tags.getString(it) },
                        o.getString("description"), o.getString("effect"),
                        o.getString("art"), o.getBoolean("secret")
                    )
                )
            }
        }.also { relicCache = it }
    }

    fun anomalies(context: Context): List<Anomaly> = anomalyCache ?: run {
        val a = JSONArray(context.assets.open("anomalies.json").bufferedReader().use { it.readText() })
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(
                    Anomaly(
                        o.getInt("id"), o.getString("name"), o.getString("code"),
                        o.getString("description"), o.getString("boostTag"), o.getDouble("multiplier")
                    )
                )
            }
        }.also { anomalyCache = it }
    }

    fun recipes(context: Context): List<SecretRecipe> = recipeCache ?: run {
        val a = JSONArray(context.assets.open("secret_recipes.json").bufferedReader().use { it.readText() })
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val req = o.getJSONArray("requires")
                add(
                    SecretRecipe(
                        o.getInt("id"), o.getString("name"), List(req.length()) { req.getInt(it) },
                        o.getInt("result"), o.getString("hint")
                    )
                )
            }
        }.also { recipeCache = it }
    }

    private fun dayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(System.currentTimeMillis())

    private fun localDayIndex(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.YEAR) * 400 + c.get(Calendar.DAY_OF_YEAR)
    }

    fun todayAnomaly(context: Context): Anomaly {
        val list = anomalies(context)
        return list[Math.floorMod(localDayIndex(), list.size)]
    }

    fun prefs(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun discoveredIds(context: Context): Set<Int> = prefs(context)
        .getStringSet("discovered", emptySet()).orEmpty()
        .mapNotNull { it.toIntOrNull() }.toSet()

    fun latestId(context: Context): Int = prefs(context).getInt("latest", 0)

    fun energy(context: Context): Int {
        val p = prefs(context)
        val today = dayKey()
        if (p.getString("energy_day", "") != today) {
            p.edit { putString("energy_day", today); putInt("energy", 3) }
        }
        return p.getInt("energy", 3)
    }

    fun spendEnergy(context: Context): Boolean {
        val e = energy(context)
        if (e <= 0) return false
        prefs(context).edit { putInt("energy", e - 1) }
        return true
    }

    fun discover(context: Context, relic: Relic, sourceUri: Uri? = null) {
        val s = discoveredIds(context).toMutableSet()
        s += relic.id
        prefs(context).edit {
            putStringSet("discovered", s.map { it.toString() }.toSet())
            putInt("latest", relic.id)
        }
        if (sourceUri != null) saveSourcePhoto(context, relic.id, sourceUri)
    }

    fun bitmap(context: Context, relic: Relic): Bitmap = renderRelicBitmap(relic)

    private fun renderRelicBitmap(relic: Relic, size: Int = 512): Bitmap {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val seed = relic.id.toLong() * 1000003L + relic.serial.hashCode().toLong() * 31L + relic.tags.joinToString().hashCode()
        val rnd = java.util.Random(seed)
        val rarityColor = when (relic.rarity) {
            "NORMAL" -> Color.rgb(120, 137, 158)
            "ODD" -> Color.rgb(77, 203, 167)
            "RARE" -> Color.rgb(79, 143, 255)
            "ANOMALOUS" -> Color.rgb(183, 91, 255)
            "RELIC" -> Color.rgb(255, 184, 67)
            "FORBIDDEN" -> Color.rgb(255, 66, 104)
            else -> Color.rgb(235, 238, 255)
        }
        val lineageHue = Math.floorMod(relic.lineageCode.hashCode(), 360).toFloat()
        val lineageColor = Color.HSVToColor(floatArrayOf(lineageHue, 0.58f, 0.92f))
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                size * .52f, size * .45f, size * .72f,
                intArrayOf(Color.rgb(30, 34, 53), Color.rgb(10, 12, 20), Color.rgb(4, 5, 9)),
                floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), bg)

        val mist = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        repeat(16) {
            val x = rnd.nextFloat() * size
            val y = rnd.nextFloat() * size
            val r = size * (.015f + rnd.nextFloat() * .06f)
            mist.color = Color.argb(18 + rnd.nextInt(26), Color.red(lineageColor), Color.green(lineageColor), Color.blue(lineageColor))
            canvas.drawCircle(x, y, r, mist)
        }

        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        repeat(5) { i ->
            ring.strokeWidth = (2 + i).toFloat()
            ring.color = Color.argb(80 - i * 10, Color.red(rarityColor), Color.green(rarityColor), Color.blue(rarityColor))
            ring.pathEffect = if (i % 2 == 0) android.graphics.DashPathEffect(floatArrayOf(10f + i*4, 8f + i*3), rnd.nextFloat()*20f) else null
            val radius = size * (.17f + i * .055f)
            canvas.drawCircle(size/2f, size*.47f, radius, ring)
        }
        ring.pathEffect = null

        val spokes = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 2f; style = Paint.Style.STROKE }
        repeat(18) { i ->
            val a = (i / 18.0 * Math.PI * 2.0 + rnd.nextDouble() * .12).toFloat()
            val r1 = size * .26f
            val r2 = size * (.34f + rnd.nextFloat()*.08f)
            spokes.color = Color.argb(45 + rnd.nextInt(50), Color.red(lineageColor), Color.green(lineageColor), Color.blue(lineageColor))
            canvas.drawLine(
                size/2f + kotlin.math.cos(a)*r1, size*.47f + kotlin.math.sin(a)*r1,
                size/2f + kotlin.math.cos(a)*r2, size*.47f + kotlin.math.sin(a)*r2,
                spokes
            )
        }

        val artifact = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = LinearGradient(
                size*.32f, size*.22f, size*.68f, size*.76f,
                intArrayOf(Color.rgb(224,228,239), lineageColor, Color.rgb(45,52,69)),
                floatArrayOf(0f,.45f,1f), Shader.TileMode.CLAMP
            )
            setShadowLayer(24f, 0f, 8f, Color.argb(150, Color.red(rarityColor), Color.green(rarityColor), Color.blue(rarityColor)))
        }
        canvas.setDrawFilter(android.graphics.PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        val cx=size/2f; val cy=size*.47f
        val form = Math.floorMod(relic.formCode.hashCode(), 6)
        when (form) {
            0 -> { // blade / obelisk
                val p=Path(); p.moveTo(cx, cy-size*.26f); p.lineTo(cx+size*.095f, cy-size*.03f); p.lineTo(cx+size*.055f, cy+size*.24f); p.lineTo(cx, cy+size*.31f); p.lineTo(cx-size*.055f, cy+size*.24f); p.lineTo(cx-size*.095f, cy-size*.03f); p.close(); canvas.drawPath(p, artifact)
            }
            1 -> { // orb cage
                canvas.drawCircle(cx, cy, size*.16f, artifact)
                val cage=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=size*.025f;color=Color.argb(220,230,235,247)}
                canvas.drawOval(cx-size*.24f,cy-size*.10f,cx+size*.24f,cy+size*.10f,cage)
                canvas.drawOval(cx-size*.10f,cy-size*.24f,cx+size*.10f,cy+size*.24f,cage)
            }
            2 -> { // crown / fork
                val p=Path(); p.moveTo(cx-size*.22f,cy+size*.20f); p.lineTo(cx-size*.18f,cy-size*.16f); p.lineTo(cx-size*.07f,cy-size*.04f); p.lineTo(cx,cy-size*.25f); p.lineTo(cx+size*.07f,cy-size*.04f); p.lineTo(cx+size*.18f,cy-size*.16f); p.lineTo(cx+size*.22f,cy+size*.20f); p.close(); canvas.drawPath(p,artifact)
            }
            3 -> { // ring device
                val outer=Paint(artifact).apply{style=Paint.Style.STROKE;strokeWidth=size*.075f}
                canvas.drawCircle(cx,cy,size*.19f,outer)
                repeat(6){ i-> val a=(i*Math.PI/3).toFloat(); canvas.drawCircle(cx+kotlin.math.cos(a)*size*.19f,cy+kotlin.math.sin(a)*size*.19f,size*.035f,artifact)}
            }
            4 -> { // reliquary box
                val p=Path(); p.moveTo(cx,cy-size*.24f); p.lineTo(cx+size*.18f,cy-size*.10f); p.lineTo(cx+size*.15f,cy+size*.21f); p.lineTo(cx,cy+size*.27f); p.lineTo(cx-size*.15f,cy+size*.21f); p.lineTo(cx-size*.18f,cy-size*.10f); p.close(); canvas.drawPath(p,artifact)
                val seam=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=4f;color=Color.argb(160,10,12,18)}; canvas.drawLine(cx,cy-size*.2f,cx,cy+size*.22f,seam)
            }
            else -> { // asymmetric machine
                canvas.drawRoundRect(cx-size*.17f,cy-size*.20f,cx+size*.17f,cy+size*.20f,size*.045f,size*.045f,artifact)
                repeat(4){ i-> val off=(-1.5f+i)*size*.07f; canvas.drawCircle(cx+off,cy-size*.21f,size*.028f,artifact); canvas.drawCircle(cx+off,cy+size*.21f,size*.028f,artifact)}
            }
        }
        artifact.clearShadowLayer(); artifact.shader = null

        val coreRadius = size * (.045f + (Math.floorMod(relic.coreCode.hashCode(), 7))*0.006f)
        val core = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(cx-size*.01f, cy-size*.015f, coreRadius*2.3f,
                intArrayOf(Color.WHITE, rarityColor, Color.argb(20,Color.red(rarityColor),Color.green(rarityColor),Color.blue(rarityColor))),
                floatArrayOf(0f,.38f,1f), Shader.TileMode.CLAMP)
        }
        canvas.drawCircle(cx,cy,coreRadius*2.3f,core)
        canvas.drawCircle(cx,cy,coreRadius,Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.WHITE})

        val detail=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=3f;color=Color.argb(170,230,235,248)}
        repeat(12){
            val a=rnd.nextDouble()*Math.PI*2; val rr=size*(.11f+rnd.nextFloat()*.10f)
            val x=(cx+Math.cos(a)*rr).toFloat(); val y=(cy+Math.sin(a)*rr).toFloat()
            val len=size*(.018f+rnd.nextFloat()*.055f)
            canvas.drawLine(x-len/2,y,x+len/2,y,detail)
            if(rnd.nextBoolean()) canvas.drawCircle(x,y,size*.008f,detail)
        }

        val label=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(210,210,218,234);textAlign=Paint.Align.CENTER;letterSpacing=.12f}
        label.textSize=size*.027f
        canvas.drawText(relic.serial, cx, size*.885f, label)
        label.color=Color.argb(135,Color.red(rarityColor),Color.green(rarityColor),Color.blue(rarityColor)); label.textSize=size*.018f
        canvas.drawText("${relic.lineageCode} / ${relic.formCode} / ${relic.coreCode}", cx, size*.925f, label)

        return bitmap
    }

    fun sourceBitmap(context: Context, relicId: Int): Bitmap? {
        val path = prefs(context).getString("source_$relicId", null) ?: return null
        val file = File(path)
        return if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
    }

    private fun saveSourcePhoto(context: Context, relicId: Int, uri: Uri) {
        runCatching {
            val raw = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
            val maxSide = maxOf(raw.width, raw.height)
            val scale = if (maxSide > 1200) 1200f / maxSide else 1f
            val outBitmap = if (scale < 1f) {
                Bitmap.createScaledBitmap(raw, (raw.width * scale).toInt(), (raw.height * scale).toInt(), true)
            } else raw
            val dir = File(context.filesDir, "source_photos").apply { mkdirs() }
            val file = File(dir, "relic_${relicId}.jpg")
            FileOutputStream(file).use { outBitmap.compress(Bitmap.CompressFormat.JPEG, 84, it) }
            prefs(context).edit { putString("source_$relicId", file.absolutePath) }
            if (outBitmap !== raw) outBitmap.recycle()
            raw.recycle()
        }
    }

    suspend fun extractEssences(context: Context, uri: Uri): List<Essence> {
        val labels = runCatching {
            val image = InputImage.fromFilePath(context, uri)
            val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
            suspendCancellableCoroutine<List<String>> { cont ->
                labeler.process(image)
                    .addOnSuccessListener { result ->
                        if (cont.isActive) {
                            cont.resume(result.sortedByDescending { it.confidence }.take(5).map { it.text })
                        }
                    }
                    .addOnFailureListener { if (cont.isActive) cont.resume(emptyList()) }
                    .addOnCompleteListener { labeler.close() }
            }
        }.getOrDefault(emptyList())

        val bm = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        val color = dominantColorName(bm)
        bm?.recycle()

        val mapped = labels.mapNotNull(::mapLabel).distinctBy { it.code }.take(2).toMutableList()
        mapped += Essence(color.first, color.second, "사진의 지배색")
        val fallback = listOf(
            Essence("ARCHIVAL", "기록", "불확실한 흔적"),
            Essence("GLASS", "반사", "표면 특징"),
            Essence("DREAM", "몽상", "형태 추정")
        )
        while (mapped.size < 3) mapped += fallback.first { f -> mapped.none { it.code == f.code } }
        return mapped.take(3)
    }

    private fun mapLabel(raw: String): Essence? {
        val s = raw.lowercase()
        val groups = listOf(
            Triple(listOf("plant", "flower", "tree", "leaf", "grass", "food", "fruit"), "VERDANT", "생명"),
            Triple(listOf("electronic", "computer", "phone", "device", "technology", "machine"), "VOLTAIC", "전하"),
            Triple(listOf("book", "paper", "text", "document", "writing"), "ARCHIVAL", "기록"),
            Triple(listOf("water", "drink", "sea", "ocean", "liquid"), "TIDAL", "조석"),
            Triple(listOf("glass", "window", "mirror", "reflection"), "GLASS", "반사"),
            Triple(listOf("metal", "tool", "vehicle", "hardware"), "MECHANICAL", "기계"),
            Triple(listOf("toy", "art", "decoration", "fashion"), "DREAM", "몽상"),
            Triple(listOf("light", "lamp", "fire", "sun"), "EMBER", "잔열")
        )
        val g = groups.firstOrNull { (keys, _, _) -> keys.any { s.contains(it) } } ?: return null
        return Essence(g.second, g.third, raw)
    }

    private fun dominantColorName(bitmap: Bitmap?): Pair<String, String> {
        if (bitmap == null) return "NOCTURNE" to "암흑"
        var r = 0L; var g = 0L; var b = 0L; var n = 0L
        val stepX = (bitmap.width / 24).coerceAtLeast(1)
        val stepY = (bitmap.height / 24).coerceAtLeast(1)
        var y = 0
        while (y < bitmap.height) {
            var x = 0
            while (x < bitmap.width) {
                val c = bitmap.getPixel(x, y)
                r += android.graphics.Color.red(c)
                g += android.graphics.Color.green(c)
                b += android.graphics.Color.blue(c)
                n++
                x += stepX
            }
            y += stepY
        }
        if (n == 0L) return "NOCTURNE" to "암흑"
        val rr = r / n; val gg = g / n; val bb = b / n
        return when {
            rr < 70 && gg < 70 && bb < 70 -> "NOCTURNE" to "암흑"
            gg.toDouble() > rr.toDouble() * 1.15 && gg.toDouble() > bb.toDouble() * 1.08 -> "VERDANT" to "녹색"
            bb.toDouble() > rr.toDouble() * 1.15 && bb.toDouble() > gg.toDouble() * 1.05 -> "TIDAL" to "청색"
            rr.toDouble() > gg.toDouble() * 1.18 && rr.toDouble() > bb.toDouble() * 1.15 -> "EMBER" to "적색"
            rr > 150 && bb > 145 && abs(rr - bb) < 45 -> "DREAM" to "자홍"
            rr > 170 && gg > 170 && bb > 170 -> "GLASS" to "백광"
            else -> "ARCHIVAL" to "중성"
        }
    }

    fun transmute(context: Context, essence: Essence): Relic {
        val all = relics(context)
        val anomaly = todayAnomaly(context)
        val rnd = Random(System.nanoTime() xor System.currentTimeMillis())
        val boosted = essence.code == anomaly.boostTag
        val roll = rnd.nextDouble()
        val rarity = if (boosted) {
            when {
                roll < .008 -> "???"
                roll < .038 -> "FORBIDDEN"
                roll < .115 -> "RELIC"
                roll < .275 -> "ANOMALOUS"
                roll < .535 -> "RARE"
                roll < .80 -> "ODD"
                else -> "NORMAL"
            }
        } else {
            when {
                roll < .005 -> "???"
                roll < .025 -> "FORBIDDEN"
                roll < .08 -> "RELIC"
                roll < .20 -> "ANOMALOUS"
                roll < .42 -> "RARE"
                roll < .72 -> "ODD"
                else -> "NORMAL"
            }
        }
        val pool = all.filter { it.rarity == rarity }
        val weighted = pool.flatMap { relic ->
            val weight = 1 + (if (relic.tags.contains(essence.code)) 4 else 0) +
                (if (relic.tags.contains(anomaly.boostTag)) 2 else 0)
            List(weight) { relic }
        }
        return (weighted.ifEmpty { pool }).random(rnd)
    }

    fun fuse(context: Context, selected: List<Relic>): FusionOutcome {
        require(selected.size == 3)
        val ids = selected.map { it.id }.sorted()
        val secret = recipes(context).firstOrNull { it.requires.sorted() == ids }
        if (secret != null) {
            val result = relics(context).first { it.id == secret.result }
            return FusionOutcome(result, secret.name, "봉인식이 해제되었습니다. 일반 합성표 밖의 결과입니다.")
        }

        val all = relics(context)
        val tags = selected.flatMap { it.tags }
        val highest = selected.maxOf { rarityScore(it.rarity) }
        val rnd = Random(System.nanoTime())
        val candidates = all.filter { candidate ->
            val overlap = candidate.tags.count { it in tags }
            overlap >= 2 && rarityScore(candidate.rarity) <= (highest + 1).coerceAtMost(6)
        }
        val pick = (candidates.ifEmpty { all }).random(rnd)
        return FusionOutcome(pick, null, "세 유물의 공통 계보가 재배열되어 새 기록이 열렸습니다.")
    }

    private fun rarityScore(r: String): Int = when (r) {
        "NORMAL" -> 0; "ODD" -> 1; "RARE" -> 2; "ANOMALOUS" -> 3
        "RELIC" -> 4; "FORBIDDEN" -> 5; else -> 6
    }
}
