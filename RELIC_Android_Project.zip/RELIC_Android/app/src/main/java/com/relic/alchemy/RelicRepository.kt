package com.relic.alchemy

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import androidx.core.content.edit
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.random.Random

object RelicRepository {
    private var relicCache: List<Relic>? = null
    private var anomalyCache: List<Anomaly>? = null
    private var recipeCache: List<SecretRecipe>? = null
    private const val PREF = "relic_state"

    fun relics(context: Context): List<Relic> = relicCache ?: run {
        val a = JSONArray(context.assets.open("relics.json").bufferedReader().use { it.readText() })
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val tags = o.getJSONArray("tags")
                add(
                    Relic(
                        o.getInt("id"), o.getString("serial"), o.getString("name"),
                        o.getString("rarity"), o.getString("rarityKr"),
                        o.getString("lineage"), o.getString("lineageCode"),
                        o.getString("form"), o.getString("formCode"),
                        o.getString("core"), o.getString("coreCode"),
                        List(tags.length()) { tags.getString(it) },
                        o.getString("description"), o.getString("effect"),
                        o.getString("art"), o.getBoolean("secret")
                    )
                )
            }
        }.also { relicCache = it }
    }

    fun anomalies(context: Context): List<Anomaly> = anomalyCache ?: run {
        val a = JSONArray(context.assets.open("anomalies.json").bufferedReader().use { it.readText() })
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(
                    Anomaly(
                        o.getInt("id"), o.getString("name"), o.getString("code"),
                        o.getString("description"), o.getString("boostTag"), o.getDouble("multiplier")
                    )
                )
            }
        }.also { anomalyCache = it }
    }

    fun recipes(context: Context): List<SecretRecipe> = recipeCache ?: run {
        val a = JSONArray(context.assets.open("secret_recipes.json").bufferedReader().use { it.readText() })
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val req = o.getJSONArray("requires")
                add(
                    SecretRecipe(
                        o.getInt("id"), o.getString("name"), List(req.length()) { req.getInt(it) },
                        o.getInt("result"), o.getString("hint")
                    )
                )
            }
        }.also { recipeCache = it }
    }

    private fun dayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(System.currentTimeMillis())

    private fun localDayIndex(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.YEAR) * 400 + c.get(Calendar.DAY_OF_YEAR)
    }

    fun todayAnomaly(context: Context): Anomaly {
        val list = anomalies(context)
        return list[Math.floorMod(localDayIndex(), list.size)]
    }

    fun prefs(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun discoveredIds(context: Context): Set<Int> = prefs(context)
        .getStringSet("discovered", emptySet()).orEmpty()
        .mapNotNull { it.toIntOrNull() }.toSet()

    fun latestId(context: Context): Int = prefs(context).getInt("latest", 0)

    fun energy(context: Context): Int {
        val p = prefs(context)
        val today = dayKey()
        if (p.getString("energy_day", "") != today) {
            p.edit { putString("energy_day", today); putInt("energy", 3) }
        }
        return p.getInt("energy", 3)
    }

    fun spendEnergy(context: Context): Boolean {
        val e = energy(context)
        if (e <= 0) return false
        prefs(context).edit { putInt("energy", e - 1) }
        return true
    }

    fun discover(context: Context, relic: Relic, sourceUri: Uri? = null) {
        val s = discoveredIds(context).toMutableSet()
        s += relic.id
        prefs(context).edit {
            putStringSet("discovered", s.map { it.toString() }.toSet())
            putInt("latest", relic.id)
        }
        if (sourceUri != null) saveSourcePhoto(context, relic.id, sourceUri)
    }

    fun bitmap(context: Context, relic: Relic): Bitmap = runCatching {
        context.assets.open(relic.art).use { BitmapFactory.decodeStream(it) }
    }.getOrNull() ?: renderRelicBitmap(relic)

    private fun renderRelicBitmap(relic: Relic, size: Int = 512): Bitmap {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val seed = relic.id.toLong() * 1000003L + relic.serial.hashCode().toLong() * 31L + relic.tags.joinToString().hashCode()
        val rnd = java.util.Random(seed)
        val rarityColor = when (relic.rarity) {
            "NORMAL" -> Color.rgb(120, 137, 158)
            "ODD" -> Color.rgb(77, 203, 167)
            "RARE" -> Color.rgb(79, 143, 255)
            "ANOMALOUS" -> Color.rgb(183, 91, 255)
            "RELIC" -> Color.rgb(255, 184, 67)
            "FORBIDDEN" -> Color.rgb(255, 66, 104)
            else -> Color.rgb(235, 238, 255)
        }
        val lineageHue = Math.floorMod(relic.lineageCode.hashCode(), 360).toFloat()
        val lineageColor = Color.HSVToColor(floatArrayOf(lineageHue, 0.58f, 0.92f))
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                size * .52f, size * .45f, size * .72f,
                intArrayOf(Color.rgb(30, 34, 53), Color.rgb(10, 12, 20), Color.rgb(4, 5, 9)),
                floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), bg)

        val mist = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        repeat(16) {
            val x = rnd.nextFloat() * size
            val y = rnd.nextFloat() * size
            val r = size * (.015f + rnd.nextFloat() * .06f)
            mist.color = Color.argb(18 + rnd.nextInt(26), Color.red(lineageColor), Color.green(lineageColor), Color.blue(lineageColor))
            canvas.drawCircle(x, y, r, mist)
        }

        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        repeat(5) { i ->
            ring.strokeWidth = (2 + i).toFloat()
            ring.color = Color.argb(80 - i * 10, Color.red(rarityColor), Color.green(rarityColor), Color.blue(rarityColor))
            ring.pathEffect = if (i % 2 == 0) android.graphics.DashPathEffect(floatArrayOf(10f + i*4, 8f + i*3), rnd.nextFloat()*20f) else null
            val radius = size * (.17f + i * .055f)
            canvas.drawCircle(size/2f, size*.47f, radius, ring)
        }
        ring.pathEffect = null

        val spokes = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 2f; style = Paint.Style.STROKE }
        repeat(18) { i ->
            val a = (i / 18.0 * Math.PI * 2.0 + rnd.nextDouble() * .12).toFloat()
            val r1 = size * .26f
            val r2 = size * (.34f + rnd.nextFloat()*.08f)
            spokes.color = Color.argb(45 + rnd.nextInt(50), Color.red(lineageColor), Color.green(lineageColor), Color.blue(lineageColor))
            canvas.drawLine(
                size/2f + kotlin.math.cos(a)*r1, size*.47f + kotlin.math.sin(a)*r1,
                size/2f + kotlin.math.cos(a)*r2, size*.47f + kotlin.math.sin(a)*r2,
                spokes
            )
        }

        val artifact = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = LinearGradient(
                size*.32f, size*.22f, size*.68f, size*.76f,
                intArrayOf(Color.rgb(224,228,239), lineageColor, Color.rgb(45,52,69)),
                floatArrayOf(0f,.45f,1f), Shader.TileMode.CLAMP
            )
            setShadowLayer(24f, 0f, 8f, Color.argb(150, Color.red(rarityColor), Color.green(rarityColor), Color.blue(rarityColor)))
        }
        canvas.setDrawFilter(android.graphics.PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        val cx=size/2f; val cy=size*.47f
        val form = Math.floorMod(relic.formCode.hashCode(), 6)
        when (form) {
            0 -> { // blade / obelisk
                val p=Path(); p.moveTo(cx, cy-size*.26f); p.lineTo(cx+size*.095f, cy-size*.03f); p.lineTo(cx+size*.055f, cy+size*.24f); p.lineTo(cx, cy+size*.31f); p.lineTo(cx-size*.055f, cy+size*.24f); p.lineTo(cx-size*.095f, cy-size*.03f); p.close(); canvas.drawPath(p, artifact)
            }
            1 -> { // orb cage
                canvas.drawCircle(cx, cy, size*.16f, artifact)
                val cage=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=size*.025f;color=Color.argb(220,230,235,247)}
                canvas.drawOval(cx-size*.24f,cy-size*.10f,cx+size*.24f,cy+size*.10f,cage)
                canvas.drawOval(cx-size*.10f,cy-size*.24f,cx+size*.10f,cy+size*.24f,cage)
            }
            2 -> { // crown / fork
                val p=Path(); p.moveTo(cx-size*.22f,cy+size*.20f); p.lineTo(cx-size*.18f,cy-size*.16f); p.lineTo(cx-size*.07f,cy-size*.04f); p.lineTo(cx,cy-size*.25f); p.lineTo(cx+size*.07f,cy-size*.04f); p.lineTo(cx+size*.18f,cy-size*.16f); p.lineTo(cx+size*.22f,cy+size*.20f); p.close(); canvas.drawPath(p,artifact)
            }
            3 -> { // ring device
                val outer=Paint(artifact).apply{style=Paint.Style.STROKE;strokeWidth=size*.075f}
                canvas.drawCircle(cx,cy,size*.19f,outer)
                repeat(6){ i-> val a=(i*Math.PI/3).toFloat(); canvas.drawCircle(cx+kotlin.math.cos(a)*size*.19f,cy+kotlin.math.sin(a)*size*.19f,size*.035f,artifact)}
            }
            4 -> { // reliquary box
                val p=Path(); p.moveTo(cx,cy-size*.24f); p.lineTo(cx+size*.18f,cy-size*.10f); p.lineTo(cx+size*.15f,cy+size*.21f); p.lineTo(cx,cy+size*.27f); p.lineTo(cx-size*.15f,cy+size*.21f); p.lineTo(cx-size*.18f,cy-size*.10f); p.close(); canvas.drawPath(p,artifact)
                val seam=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=4f;color=Color.argb(160,10,12,18)}; canvas.drawLine(cx,cy-size*.2f,cx,cy+size*.22f,seam)
            }
            else -> { // asymmetric machine
                canvas.drawRoundRect(cx-size*.17f,cy-size*.20f,cx+size*.17f,cy+size*.20f,size*.045f,size*.045f,artifact)
                repeat(4){ i-> val off=(-1.5f+i)*size*.07f; canvas.drawCircle(cx+off,cy-size*.21f,size*.028f,artifact); canvas.drawCircle(cx+off,cy+size*.21f,size*.028f,artifact)}
            }
        }
        artifact.clearShadowLayer(); artifact.shader = null

        val coreRadius = size * (.045f + (Math.floorMod(relic.coreCode.hashCode(), 7))*0.006f)
        val core = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(cx-size*.01f, cy-size*.015f, coreRadius*2.3f,
                intArrayOf(Color.WHITE, rarityColor, Color.argb(20,Color.red(rarityColor),Color.green(rarityColor),Color.blue(rarityColor))),
                floatArrayOf(0f,.38f,1f), Shader.TileMode.CLAMP)
        }
        canvas.drawCircle(cx,cy,coreRadius*2.3f,core)
        canvas.drawCircle(cx,cy,coreRadius,Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.WHITE})

        val detail=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=3f;color=Color.argb(170,230,235,248)}
        repeat(12){
            val a=rnd.nextDouble()*Math.PI*2; val rr=size*(.11f+rnd.nextFloat()*.10f)
            val x=(cx+Math.cos(a)*rr).toFloat(); val y=(cy+Math.sin(a)*rr).toFloat()
            val len=size*(.018f+rnd.nextFloat()*.055f)
            canvas.drawLine(x-len/2,y,x+len/2,y,detail)
            if(rnd.nextBoolean()) canvas.drawCircle(x,y,size*.008f,detail)
        }

        val label=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(210,210,218,234);textAlign=Paint.Align.CENTER;letterSpacing=.12f}
        label.textSize=size*.027f
        canvas.drawText(relic.serial, cx, size*.885f, label)
        label.color=Color.argb(135,Color.red(rarityColor),Color.green(rarityColor),Color.blue(rarityColor)); label.textSize=size*.018f
        canvas.drawText("${relic.lineageCode} / ${relic.formCode} / ${relic.coreCode}", cx, size*.925f, label)

        return bitmap
    }

    fun sourceBitmap(context: Context, relicId: Int): Bitmap? {
        val path = prefs(context).getString("source_$relicId", null) ?: return null
        val file = File(path)
        return if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
    }

    private fun saveSourcePhoto(context: Context, relicId: Int, uri: Uri) {
        runCatching {
            val raw = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
            val maxSide = maxOf(raw.width, raw.height)
            val scale = if (maxSide > 1200) 1200f / maxSide else 1f
            val outBitmap = if (scale < 1f) {
                Bitmap.createScaledBitmap(raw, (raw.width * scale).toInt(), (raw.height * scale).toInt(), true)
            } else raw
            val dir = File(context.filesDir, "source_photos").apply { mkdirs() }
            val file = File(dir, "relic_${relicId}.jpg")
            FileOutputStream(file).use { outBitmap.compress(Bitmap.CompressFormat.JPEG, 84, it) }
            prefs(context).edit { putString("source_$relicId", file.absolutePath) }
            if (outBitmap !== raw) outBitmap.recycle()
            raw.recycle()
        }
    }

    suspend fun extractEssences(context: Context, uri: Uri): List<Essence> {
        val labels = runCatching {
            val image = InputImage.fromFilePath(context, uri)
            val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
            suspendCancellableCoroutine<List<String>> { cont ->
                labeler.process(image)
                    .addOnSuccessListener { result ->
                        if (cont.isActive) {
                            cont.resume(result.sortedByDescending { it.confidence }.take(5).map { it.text })
                        }
                    }
                    .addOnFailureListener { if (cont.isActive) cont.resume(emptyList()) }
                    .addOnCompleteListener { labeler.close() }
            }
        }.getOrDefault(emptyList())

        val bm = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        val color = dominantColorName(bm)
        bm?.recycle()

        val mapped = labels.mapNotNull(::mapLabel).distinctBy { it.code }.take(2).toMutableList()
        mapped += Essence(color.first, color.second, "사진의 지배색")
        val fallback = listOf(
            Essence("ARCHIVAL", "기록", "불확실한 흔적"),
            Essence("GLASS", "반사", "표면 특징"),
            Essence("DREAM", "몽상", "형태 추정")
        )
        while (mapped.size < 3) mapped += fallback.first { f -> mapped.none { it.code == f.code } }
        return mapped.take(3)
    }

    private fun mapLabel(raw: String): Essence? {
        val s = raw.lowercase()
        val groups = listOf(
            Triple(listOf("plant", "flower", "tree", "leaf", "grass", "food", "fruit"), "VERDANT", "생명"),
            Triple(listOf("electronic", "computer", "phone", "device", "technology", "machine"), "VOLTAIC", "전하"),
            Triple(listOf("book", "paper", "text", "document", "writing"), "ARCHIVAL", "기록"),
            Triple(listOf("water", "drink", "sea", "ocean", "liquid"), "TIDAL", "조석"),
            Triple(listOf("glass", "window", "mirror", "reflection"), "GLASS", "반사"),
            Triple(listOf("metal", "tool", "vehicle", "hardware"), "MECHANICAL", "기계"),
            Triple(listOf("toy", "art", "decoration", "fashion"), "DREAM", "몽상"),
            Triple(listOf("light", "lamp", "fire", "sun"), "EMBER", "잔열")
        )
        val g = groups.firstOrNull { (keys, _, _) -> keys.any { s.contains(it) } } ?: return null
        return Essence(g.second, g.third, raw)
    }

    private fun dominantColorName(bitmap: Bitmap?): Pair<String, String> {
        if (bitmap == null) return "NOCTURNE" to "암흑"
        var r = 0L; var g = 0L; var b = 0L; var n = 0L
        val stepX = (bitmap.width / 24).coerceAtLeast(1)
        val stepY = (bitmap.height / 24).coerceAtLeast(1)
        var y = 0
        while (y < bitmap.height) {
            var x = 0
            while (x < bitmap.width) {
                val c = bitmap.getPixel(x, y)
                r += android.graphics.Color.red(c)
                g += android.graphics.Color.green(c)
                b += android.graphics.Color.blue(c)
                n++
                x += stepX
            }
            y += stepY
        }
        if (n == 0L) return "NOCTURNE" to "암흑"
        val rr = r / n; val gg = g / n; val bb = b / n
        return when {
            rr < 70 && gg < 70 && bb < 70 -> "NOCTURNE" to "암흑"
            gg.toDouble() > rr.toDouble() * 1.15 && gg.toDouble() > bb.toDouble() * 1.08 -> "VERDANT" to "녹색"
            bb.toDouble() > rr.toDouble() * 1.15 && bb.toDouble() > gg.toDouble() * 1.05 -> "TIDAL" to "청색"
            rr.toDouble() > gg.toDouble() * 1.18 && rr.toDouble() > bb.toDouble() * 1.15 -> "EMBER" to "적색"
            rr > 150 && bb > 145 && abs(rr - bb) < 45 -> "DREAM" to "자홍"
            rr > 170 && gg > 170 && bb > 170 -> "GLASS" to "백광"
            else -> "ARCHIVAL" to "중성"
        }
    }

    fun transmute(context: Context, essence: Essence): Relic {
        val all = relics(context)
        val anomaly = todayAnomaly(context)
        val rnd = Random(System.nanoTime() xor System.currentTimeMillis())
        val boosted = essence.code == anomaly.boostTag
        val roll = rnd.nextDouble()
        val rarity = if (boosted) {
            when {
                roll < .008 -> "???"
                roll < .038 -> "FORBIDDEN"
                roll < .115 -> "RELIC"
                roll < .275 -> "ANOMALOUS"
                roll < .535 -> "RARE"
                roll < .80 -> "ODD"
                else -> "NORMAL"
            }
        } else {
            when {
                roll < .005 -> "???"
                roll < .025 -> "FORBIDDEN"
                roll < .08 -> "RELIC"
                roll < .20 -> "ANOMALOUS"
                roll < .42 -> "RARE"
                roll < .72 -> "ODD"
                else -> "NORMAL"
            }
        }
        val pool = all.filter { it.rarity == rarity }
        val weighted = pool.flatMap { relic ->
            val weight = 1 + (if (relic.tags.contains(essence.code)) 4 else 0) +
                (if (relic.tags.contains(anomaly.boostTag)) 2 else 0)
            List(weight) { relic }
        }
        return (weighted.ifEmpty { pool }).random(rnd)
    }

    fun fuse(context: Context, selected: List<Relic>): FusionOutcome {
        require(selected.size == 3)
        val ids = selected.map { it.id }.sorted()
        val secret = recipes(context).firstOrNull { it.requires.sorted() == ids }
        if (secret != null) {
            val result = relics(context).first { it.id == secret.result }
            return FusionOutcome(result, secret.name, "봉인식이 해제되었습니다. 일반 합성표 밖의 결과입니다.")
        }

        val all = relics(context)
        val tags = selected.flatMap { it.tags }
        val highest = selected.maxOf { rarityScore(it.rarity) }
        val rnd = Random(System.nanoTime())
        val candidates = all.filter { candidate ->
            val overlap = candidate.tags.count { it in tags }
            overlap >= 2 && rarityScore(candidate.rarity) <= (highest + 1).coerceAtMost(6)
        }
        val pick = (candidates.ifEmpty { all }).random(rnd)
        return FusionOutcome(pick, null, "세 유물의 공통 계보가 재배열되어 새 기록이 열렸습니다.")
    }

    fun rarityScore(r: String): Int = when (r) {
        "NORMAL" -> 0; "ODD" -> 1; "RARE" -> 2; "ANOMALOUS" -> 3
        "RELIC" -> 4; "FORBIDDEN" -> 5; else -> 6
    }

    fun zones(): List<RiftZone> = listOf(
        RiftZone(
            1, "R-01", "침묵한 주거구", "사람은 떠났지만 생활 소음은 남아 있다",
            "대피가 끝난 뒤에도 인터폰, 현관 센서, 수도 계량기가 매일 같은 시간에 작동하는 아파트 단지. 잔향이 가장 약하지만 사물의 습관이 생명처럼 행동하기 시작한 최초의 구역이다.",
            "비어 있는 복도 · 켜졌다 꺼지는 센서등 · 벽 너머의 발소리",
            "기록 계열 공격은 안정적이고, 기계 계열 유물은 경보 장치를 무력화한다.",
            listOf("ARCHIVAL", "MECHANICAL"),
            listOf(
                RiftEnemy(11,1,"문틈의 이웃","생활 잔향","문이 열리기를 기다리는 현관 센서와 목소리 조각이 엉겨 만든 작은 이상체.",listOf("ARCHIVAL","GLASS"),95,10,18),
                RiftEnemy(12,2,"자동응답 전화기","반복 신호","받는 사람이 없는 번호로 계속 전화를 거는 통신 잔향.",listOf("VOLTAIC","ARCHIVAL"),120,12,22),
                RiftEnemy(13,3,"복도 순찰자","기계 습관","청소 로봇과 보안 카메라의 이동 기록이 한 덩어리로 굳었다.",listOf("MECHANICAL","VOLTAIC"),145,14,26),
                RiftEnemy(14,4,"벽 너머의 집주인","구역 핵심체","모든 방의 생활 기록을 자기 소유라고 주장하는 주거구의 핵심 잔향.",listOf("ARCHIVAL","NOCTURNE"),205,17,45,true)
            )
        ),
        RiftZone(
            2, "R-02", "0번 환승역", "막차 이후에도 도착 안내가 계속된다",
            "지도에 없는 승강장이 전광판 오류처럼 나타나는 지하 환승역. 시간표와 승객의 목적지가 서로 뒤섞여, 길을 잘못 고르면 같은 계단을 반복하게 된다.",
            "젖은 플랫폼 · 뒤집힌 노선도 · 목적지가 없는 열차",
            "전하와 조석 속성이 선로 잔향에 강하다. 기록 속성은 가짜 안내를 판별한다.",
            listOf("VOLTAIC", "TIDAL", "ARCHIVAL"),
            listOf(
                RiftEnemy(21,1,"막차 안내음","음성 잔향","스피커에서 떨어져 나온 안내방송이 플랫폼을 떠돈다.",listOf("VOLTAIC","ARCHIVAL"),135,14,24),
                RiftEnemy(22,2,"무표 승객","목적지 결손","표도 얼굴도 없이 개찰구를 통과하려는 승객 형태의 잔향.",listOf("GLASS","NOCTURNE"),160,15,28),
                RiftEnemy(23,3,"선로 수집자","철도 잔향","버려진 금속 조각과 운행 기록을 끌어모아 몸을 키운다.",listOf("MECHANICAL","VOLTAIC"),185,17,32),
                RiftEnemy(24,4,"0번 승강장의 기관사","구역 핵심체","존재하지 않는 막차를 영원히 운행하는 기관사형 핵심체.",listOf("TIDAL","ARCHIVAL"),255,20,52,true)
            )
        ),
        RiftZone(
            3, "R-03", "적우 시장", "비가 내릴 때만 가격표가 바뀐다",
            "폐쇄된 야시장에 붉은 비가 내리면 진열대가 다시 펼쳐진다. 물건마다 가격 대신 기억 한 조각이 붙어 있고, 오래 머물수록 자신의 기억과 거래가 시작된다.",
            "붉은 천막 · 젖은 간판 · 끝없이 늘어나는 영수증",
            "잔열과 생명 계열이 적우에 강하고, 기록 계열은 거래 효과를 줄인다.",
            listOf("EMBER", "VERDANT", "ARCHIVAL"),
            listOf(
                RiftEnemy(31,1,"가격표 벌레","교환 잔향","숫자가 적힌 종이 조각들이 곤충처럼 붙어 다닌다.",listOf("EMBER","ARCHIVAL"),170,17,28),
                RiftEnemy(32,2,"폐점 방송","상점 신호","이미 문 닫은 점포의 마지막 안내가 실체를 얻었다.",listOf("VOLTAIC","ARCHIVAL"),195,18,32),
                RiftEnemy(33,3,"붉은 우산 군집","기상 잔향","주인을 잃은 우산들이 빗물과 함께 움직이는 군집체.",listOf("TIDAL","EMBER"),220,20,36),
                RiftEnemy(34,4,"영수증 왕","구역 핵심체","시장 전체의 거래 기록을 한 장의 끝없는 영수증으로 합친 핵심체.",listOf("ARCHIVAL","VERDANT"),305,23,60,true)
            )
        ),
        RiftZone(
            4, "R-04", "정전 연구동", "전기가 끊긴 뒤 실험은 더 활발해졌다",
            "잔향을 인공적으로 증폭하던 연구동. 비상전원이 꺼진 뒤에도 실험 장비는 스스로 전류를 만들며, 실패한 실험 로그를 다시 실행한다.",
            "검은 서버랙 · 번쩍이는 케이블 · 잠긴 격리실",
            "전하와 기계 속성이 핵심. 유리 속성은 실험실 방어막을 빠르게 깎는다.",
            listOf("VOLTAIC", "MECHANICAL", "GLASS"),
            listOf(
                RiftEnemy(41,1,"잔류 전류","누설 잔향","바닥 케이블을 따라 이동하는 자율 전류 덩어리.",listOf("GLASS","MECHANICAL"),205,20,32),
                RiftEnemy(42,2,"로그 재생기","실험 기록","실패한 실험을 반복하며 주변 장비를 강제로 동기화한다.",listOf("ARCHIVAL","VOLTAIC"),235,22,36),
                RiftEnemy(43,3,"격리실 문지기","보안 잔향","잠금장치와 경고등이 결합한 방어형 이상체.",listOf("MECHANICAL","GLASS"),270,24,42),
                RiftEnemy(44,4,"블랙아웃 코어","구역 핵심체","전력이 없을수록 강해지는 연구동의 자가발전 핵심 잔향.",listOf("VOLTAIC","NOCTURNE"),365,28,70,true)
            )
        ),
        RiftZone(
            5, "R-05", "무명 쇼핑몰", "모든 브랜드명이 지워진 채 영업 중이다",
            "간판과 로고가 전부 사라진 대형 쇼핑몰. 마네킹은 손님의 취향을 흉내 내고, 엘리베이터는 존재하지 않는 층을 선택지로 띄운다.",
            "흰 마네킹 · 무명 매장 · 끝없이 반복되는 에스컬레이터",
            "몽상과 반사 속성이 위장형 이상체를 드러낸다. 기록 속성은 층 구조 변화를 억제한다.",
            listOf("DREAM", "GLASS", "ARCHIVAL"),
            listOf(
                RiftEnemy(51,1,"빈 쇼윈도","반사 잔향","진열되지 않은 물건의 형태만 유리에 반복해서 나타난다.",listOf("GLASS","DREAM"),240,23,36),
                RiftEnemy(52,2,"취향 마네킹","모방 잔향","관측자의 장비 구성을 흉내 내는 마네킹.",listOf("DREAM","EMBER"),275,25,42),
                RiftEnemy(53,3,"에스컬레이터 포식층","공간 잔향","같은 층을 반복시키며 이동 기록을 흡수한다.",listOf("ARCHIVAL","MECHANICAL"),310,27,48),
                RiftEnemy(54,4,"점장 없는 점장실","구역 핵심체","쇼핑몰 전체의 선택과 소비 기록을 관리하는 비어 있는 사무실형 핵심체.",listOf("DREAM","ARCHIVAL"),420,31,80,true)
            )
        ),
        RiftZone(
            6, "R-06", "침수 수족관", "수조 밖에도 파도가 친다",
            "지하 수족관의 유리가 깨지지 않았는데 도시의 바닷물이 내부로 역류했다. 물속에서는 소리와 빛의 방향이 바뀌며, 오래된 관람객의 감정이 생물처럼 헤엄친다.",
            "푸른 비상등 · 떠다니는 안내판 · 물속의 발자국",
            "조석과 유리 속성 우세. 전하는 위험하지만 공명 성공 시 큰 피해를 준다.",
            listOf("TIDAL", "GLASS", "VOLTAIC"),
            listOf(
                RiftEnemy(61,1,"빈 수조의 그림자","수중 잔향","아무것도 없는 수조 안에서만 움직이는 어두운 형상.",listOf("GLASS","TIDAL"),285,26,42),
                RiftEnemy(62,2,"역류 안내판","방향 잔향","화살표가 계속 바뀌며 길 자체를 밀어낸다.",listOf("ARCHIVAL","TIDAL"),320,28,48),
                RiftEnemy(63,3,"청색 군집어","감정 잔향","관람객의 놀람과 공포가 작은 빛무리로 뭉쳤다.",listOf("VOLTAIC","DREAM"),355,30,54),
                RiftEnemy(64,4,"수심 없는 고래","구역 핵심체","공간보다 큰 울음만 남은 수족관의 핵심 잔향.",listOf("TIDAL","DREAM"),485,35,92,true)
            )
        ),
        RiftZone(
            7, "R-07", "유리 사막", "깨진 창문들이 모여 지평선을 만들었다",
            "도시의 모든 반사면이 한 장소로 밀려 들어가 만들어진 비현실적 사막. 모래 대신 미세한 유리 조각이 빛을 저장하며, 먼 곳의 풍경이 현재보다 먼저 보인다.",
            "반사 지평선 · 뒤늦게 움직이는 그림자 · 빛을 품은 모래",
            "반사와 잔열이 강력하다. 암흑 계열은 예측 잔향을 무시한다.",
            listOf("GLASS", "EMBER", "NOCTURNE"),
            listOf(
                RiftEnemy(71,1,"반사 전갈","광학 잔향","빛의 각도에 따라 위치가 바뀌는 작은 포식 잔향.",listOf("NOCTURNE","GLASS"),335,30,48),
                RiftEnemy(72,2,"뒤늦은 그림자","시간 오차","본체보다 한 박자 늦게 나타나 공격을 반복한다.",listOf("EMBER","NOCTURNE"),375,32,54),
                RiftEnemy(73,3,"프리즘 순례자","광학 기록","여러 시간대의 모습을 동시에 비추는 인간형 잔향.",listOf("GLASS","ARCHIVAL"),415,35,62),
                RiftEnemy(74,4,"천 개의 태양","구역 핵심체","모든 반사광을 하나로 모아 사막 전체를 밝히는 핵심체.",listOf("NOCTURNE","TIDAL"),565,40,105,true)
            )
        ),
        RiftZone(
            8, "R-08", "역류 발전소", "에너지가 소비될수록 저장량이 늘어난다",
            "도시 외곽 발전소가 잔향권과 연결되며 인과가 역전되었다. 기계를 멈추면 더 빠르게 회전하고, 전력을 사용하면 오히려 저장량이 증가한다.",
            "거꾸로 도는 터빈 · 뜨거운 냉각수 · 역방향 계기판",
            "기계·전하·잔열 조합이 중요. 같은 태그 2개 이상을 편성하면 공명 보너스가 커진다.",
            listOf("MECHANICAL", "VOLTAIC", "EMBER"),
            listOf(
                RiftEnemy(81,1,"역회전 터빈","기계 잔향","멈추려 할수록 속도가 올라가는 터빈형 이상체.",listOf("MECHANICAL","TIDAL"),390,34,54),
                RiftEnemy(82,2,"과충전 계전기","전하 잔향","피해를 받을 때 주변 전류를 끌어모은다.",listOf("VOLTAIC","GLASS"),435,37,62),
                RiftEnemy(83,3,"냉각수 열원","역전 잔향","차가운 액체가 주변을 가열하는 모순된 열원.",listOf("TIDAL","EMBER"),485,39,70),
                RiftEnemy(84,4,"무한 출력기","구역 핵심체","소비와 생산의 경계가 사라진 발전소의 중심 장치.",listOf("MECHANICAL","VOLTAIC"),650,45,120,true)
            )
        ),
        RiftZone(
            9, "R-09", "제0보관소", "도감에서 삭제된 것들이 보관된 장소",
            "RE:LIC 이전 세대의 실험 유물을 봉인했던 지하 시설. 정규 분류에 맞지 않는 기록들이 서로 이름을 바꾸며, 입장자의 도감 정보까지 오염시킨다.",
            "번호 없는 서랍 · 붉은 봉인등 · 이름이 바뀌는 라벨",
            "기록·암흑·몽상 태그가 봉인 교란에 강하다. FORBIDDEN 등급은 추가 공명을 얻는다.",
            listOf("ARCHIVAL", "NOCTURNE", "DREAM"),
            listOf(
                RiftEnemy(91,1,"번호 없는 상자","미분류 잔향","열 때마다 내부 분류가 바뀌는 보관함형 이상체.",listOf("ARCHIVAL","DREAM"),455,38,62),
                RiftEnemy(92,2,"삭제 관리자","봉인 잔향","도감에서 항목명을 지워 공격 패턴을 숨긴다.",listOf("NOCTURNE","ARCHIVAL"),505,41,70),
                RiftEnemy(93,3,"붉은 봉인문","경계 잔향","보관소의 모든 금지 기록을 문 하나에 압축했다.",listOf("DREAM","GLASS"),565,44,82),
                RiftEnemy(94,4,"미등록 000","구역 핵심체","어느 실험 기록에도 존재하지 않지만 가장 오래 보관되어 있던 핵심체.",listOf("ARCHIVAL","NOCTURNE"),760,50,140,true)
            )
        ),
        RiftZone(
            10, "R-10", "잔향권 중심부", "현실의 사용 흔적이 태어나는 최초 지점",
            "모든 연구구역의 잔향이 흐르는 중심. 건물과 거리 대신 기억된 사물의 윤곽이 지형을 만들고, 지금까지 수집한 유물들이 주변 공간에 반응한다.",
            "형태가 없는 도시 · 겹쳐진 열 개의 하늘 · 중심의 백색 균열",
            "고정 약점이 없다. 매 턴 약점이 바뀐다는 설정을 반영해 다양한 태그의 유물을 편성하는 것이 유리하다.",
            listOf("ARCHIVAL", "VOLTAIC", "TIDAL", "GLASS", "MECHANICAL", "DREAM", "EMBER", "VERDANT", "NOCTURNE"),
            listOf(
                RiftEnemy(101,1,"계보의 잔상","복합 잔향","지나온 아홉 구역의 행동 패턴을 조각처럼 재현한다.",listOf("VERDANT","MECHANICAL","GLASS"),530,43,72),
                RiftEnemy(102,2,"도감 외곽선","기록 결손","아직 얻지 못한 유물의 빈자리만으로 만들어진 이상체.",listOf("ARCHIVAL","DREAM","NOCTURNE"),595,47,82),
                RiftEnemy(103,3,"백색 균열","원형 잔향","속성과 등급을 잠시 무효화하는 중심부의 방어 반응.",listOf("EMBER","TIDAL","VOLTAIC"),665,51,95),
                RiftEnemy(104,4,"최초의 잔향","최종 핵심체","사물이 사용된 순간과 기억된 순간 사이에 처음 생긴 오차. RE:LIC의 모든 기록이 이곳으로 이어진다.",listOf("ARCHIVAL","DREAM","VOLTAIC","GLASS"),900,58,200,true)
            )
        )
    )

    fun fragments(context: Context): Int = prefs(context).getInt("fragments", 0)
    fun unlockedZone(context: Context): Int = prefs(context).getInt("zone_unlocked", 1).coerceIn(1, 10)
    fun zoneProgress(context: Context, zoneId: Int): Int = prefs(context).getInt("zone_${zoneId}_progress", 0).coerceIn(0, 4)

    fun currentRift(context: Context): Pair<RiftZone, RiftEnemy> {
        val zone = zones().first { it.id == unlockedZone(context) }
        val progress = zoneProgress(context, zone.id)
        val enemy = zone.enemies[progress.coerceAtMost(3)]
        return zone to enemy
    }

    fun battlePower(relic: Relic, enemy: RiftEnemy): Int {
        val rarity = 12 + rarityScore(relic.rarity) * 8
        val match = relic.tags.count { it in enemy.weakTags } * 11
        val special = if (relic.rarity == "FORBIDDEN" || relic.rarity == "???") 8 else 0
        return rarity + match + special
    }

    fun startBattle(context: Context, zone: RiftZone, enemy: RiftEnemy, loadout: List<Relic>): BattleSession {
        val defense = loadout.sumOf { rarityScore(it.rarity) }
        val maxHp = 100 + defense * 5
        return BattleSession(
            zoneId = zone.id,
            enemy = enemy,
            loadoutIds = loadout.map { it.id },
            playerMaxHp = maxHp,
            playerHp = maxHp,
            enemyMaxHp = enemy.hp,
            enemyHp = enemy.hp,
            resonance = 1,
            turn = 1,
            log = listOf("${zone.name}에서 ${enemy.name}의 신호를 포착했다."),
            finished = false,
            victory = false
        )
    }

    fun battleTurn(context: Context, session: BattleSession, action: String): BattleSession {
        if (session.finished) return session
        val allById = relics(context).associateBy { it.id }
        val loadout = session.loadoutIds.mapNotNull { allById[it] }
        val rawPower = loadout.sumOf { battlePower(it, session.enemy) }.coerceAtLeast(20)
        val synergyTags = loadout.flatMap { it.tags }.groupingBy { it }.eachCount().count { it.value >= 2 }
        val synergy = 1.0 + synergyTags * 0.08
        var resonance = session.resonance
        var playerHp = session.playerHp
        var enemyHp = session.enemyHp
        val logs = session.log.toMutableList()

        val damage = when (action) {
            "RESONATE" -> {
                if (resonance <= 0) {
                    logs += "공명력이 부족해 기본 타격으로 전환됐다."
                    (rawPower * 0.24 * synergy).toInt()
                } else {
                    resonance -= 1
                    logs += "세 유물의 핵이 동시에 공명했다."
                    (rawPower * 0.48 * synergy).toInt()
                }
            }
            "OVERLOAD" -> {
                playerHp = (playerHp - 8).coerceAtLeast(1)
                logs += "출력을 강제로 끌어올렸다. 안정도 -8."
                (rawPower * 0.62 * synergy).toInt()
            }
            else -> {
                resonance = (resonance + if (session.turn % 2 == 0) 1 else 0).coerceAtMost(3)
                logs += "유물 배열로 안정적인 타격을 가했다."
                (rawPower * 0.30 * synergy).toInt()
            }
        }.coerceAtLeast(8)

        enemyHp = (enemyHp - damage).coerceAtLeast(0)
        logs += "${session.enemy.name}에 $damage 공명 피해."

        if (enemyHp <= 0) {
            recordVictory(context, session.zoneId, session.enemy)
            logs += "균열 안정화 성공. 잔향 파편 +${session.enemy.reward}."
            return session.copy(
                playerHp = playerHp,
                enemyHp = 0,
                resonance = resonance,
                turn = session.turn + 1,
                log = logs.takeLast(8),
                finished = true,
                victory = true
            )
        }

        val special = session.turn % 3 == 0
        val defense = loadout.sumOf { rarityScore(it.rarity) } / 2
        val incoming = (session.enemy.attack + (if (special) 8 + session.zoneId * 2 else 0) - defense).coerceAtLeast(4)
        playerHp = (playerHp - incoming).coerceAtLeast(0)
        logs += if (special) "${session.enemy.name}의 특수 반응. 안정도 -$incoming." else "적 반응으로 안정도 -$incoming."

        val lost = playerHp <= 0
        if (lost) logs += "연결이 끊겼다. 장비는 보존되며 다시 도전할 수 있다."
        return session.copy(
            playerHp = playerHp,
            enemyHp = enemyHp,
            resonance = resonance,
            turn = session.turn + 1,
            log = logs.takeLast(8),
            finished = lost,
            victory = false
        )
    }

    private fun recordVictory(context: Context, zoneId: Int, enemy: RiftEnemy) {
        val p = prefs(context)
        val progress = zoneProgress(context, zoneId)
        val nextProgress = if (enemy.order == progress + 1) (progress + 1).coerceAtMost(4) else progress
        p.edit {
            putInt("fragments", p.getInt("fragments", 0) + enemy.reward)
            if (nextProgress != progress) putInt("zone_${zoneId}_progress", nextProgress)
            if (nextProgress >= 4 && zoneId < 10) putInt("zone_unlocked", maxOf(p.getInt("zone_unlocked", 1), zoneId + 1))
        }
    }
}
