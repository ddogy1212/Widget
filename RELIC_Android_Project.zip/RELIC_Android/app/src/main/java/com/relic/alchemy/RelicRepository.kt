package com.relic.alchemy

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.core.content.edit
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.random.Random

object RelicRepository {
    private var relicCache: List<Relic>? = null
    private var anomalyCache: List<Anomaly>? = null
    private var recipeCache: List<SecretRecipe>? = null
    private const val PREF = "relic_state"

    fun relics(context: Context): List<Relic> = relicCache ?: run {
        val a = JSONArray(context.assets.open("relics.json").bufferedReader().use { it.readText() })
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val tags = o.getJSONArray("tags")
                add(
                    Relic(
                        o.getInt("id"), o.getString("serial"), o.getString("name"),
                        o.getString("rarity"), o.getString("rarityKr"),
                        o.getString("lineage"), o.getString("lineageCode"),
                        o.getString("form"), o.getString("formCode"),
                        o.getString("core"), o.getString("coreCode"),
                        List(tags.length()) { tags.getString(it) },
                        o.getString("description"), o.getString("effect"),
                        o.getString("art"), o.getBoolean("secret")
                    )
                )
            }
        }.also { relicCache = it }
    }

    fun anomalies(context: Context): List<Anomaly> = anomalyCache ?: run {
        val a = JSONArray(context.assets.open("anomalies.json").bufferedReader().use { it.readText() })
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(
                    Anomaly(
                        o.getInt("id"), o.getString("name"), o.getString("code"),
                        o.getString("description"), o.getString("boostTag"), o.getDouble("multiplier")
                    )
                )
            }
        }.also { anomalyCache = it }
    }

    fun recipes(context: Context): List<SecretRecipe> = recipeCache ?: run {
        val a = JSONArray(context.assets.open("secret_recipes.json").bufferedReader().use { it.readText() })
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val req = o.getJSONArray("requires")
                add(
                    SecretRecipe(
                        o.getInt("id"), o.getString("name"), List(req.length()) { req.getInt(it) },
                        o.getInt("result"), o.getString("hint")
                    )
                )
            }
        }.also { recipeCache = it }
    }

    private fun dayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(System.currentTimeMillis())

    private fun localDayIndex(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.YEAR) * 400 + c.get(Calendar.DAY_OF_YEAR)
    }

    fun todayAnomaly(context: Context): Anomaly {
        val list = anomalies(context)
        return list[Math.floorMod(localDayIndex(), list.size)]
    }

    fun prefs(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun discoveredIds(context: Context): Set<Int> = prefs(context)
        .getStringSet("discovered", emptySet()).orEmpty()
        .mapNotNull { it.toIntOrNull() }.toSet()

    fun latestId(context: Context): Int = prefs(context).getInt("latest", 0)

    fun energy(context: Context): Int {
        val p = prefs(context)
        val today = dayKey()
        if (p.getString("energy_day", "") != today) {
            p.edit { putString("energy_day", today); putInt("energy", 3) }
        }
        return p.getInt("energy", 3)
    }

    fun spendEnergy(context: Context): Boolean {
        val e = energy(context)
        if (e <= 0) return false
        prefs(context).edit { putInt("energy", e - 1) }
        return true
    }

    fun discover(context: Context, relic: Relic, sourceUri: Uri? = null) {
        val s = discoveredIds(context).toMutableSet()
        s += relic.id
        prefs(context).edit {
            putStringSet("discovered", s.map { it.toString() }.toSet())
            putInt("latest", relic.id)
        }
        if (sourceUri != null) saveSourcePhoto(context, relic.id, sourceUri)
    }

    fun bitmap(context: Context, relic: Relic): Bitmap =
        context.assets.open(relic.art).use { BitmapFactory.decodeStream(it) }

    fun sourceBitmap(context: Context, relicId: Int): Bitmap? {
        val path = prefs(context).getString("source_$relicId", null) ?: return null
        val file = File(path)
        return if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
    }

    private fun saveSourcePhoto(context: Context, relicId: Int, uri: Uri) {
        runCatching {
            val raw = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
            val maxSide = maxOf(raw.width, raw.height)
            val scale = if (maxSide > 1200) 1200f / maxSide else 1f
            val outBitmap = if (scale < 1f) {
                Bitmap.createScaledBitmap(raw, (raw.width * scale).toInt(), (raw.height * scale).toInt(), true)
            } else raw
            val dir = File(context.filesDir, "source_photos").apply { mkdirs() }
            val file = File(dir, "relic_${relicId}.jpg")
            FileOutputStream(file).use { outBitmap.compress(Bitmap.CompressFormat.JPEG, 84, it) }
            prefs(context).edit { putString("source_$relicId", file.absolutePath) }
            if (outBitmap !== raw) outBitmap.recycle()
            raw.recycle()
        }
    }

    suspend fun extractEssences(context: Context, uri: Uri): List<Essence> {
        val labels = runCatching {
            val image = InputImage.fromFilePath(context, uri)
            val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
            suspendCancellableCoroutine<List<String>> { cont ->
                labeler.process(image)
                    .addOnSuccessListener { result ->
                        if (cont.isActive) {
                            cont.resume(result.sortedByDescending { it.confidence }.take(5).map { it.text })
                        }
                    }
                    .addOnFailureListener { if (cont.isActive) cont.resume(emptyList()) }
                    .addOnCompleteListener { labeler.close() }
            }
        }.getOrDefault(emptyList())

        val bm = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        val color = dominantColorName(bm)
        bm?.recycle()

        val mapped = labels.mapNotNull(::mapLabel).distinctBy { it.code }.take(2).toMutableList()
        mapped += Essence(color.first, color.second, "사진의 지배색")
        val fallback = listOf(
            Essence("ARCHIVAL", "기록", "불확실한 흔적"),
            Essence("GLASS", "반사", "표면 특징"),
            Essence("DREAM", "몽상", "형태 추정")
        )
        while (mapped.size < 3) mapped += fallback.first { f -> mapped.none { it.code == f.code } }
        return mapped.take(3)
    }

    private fun mapLabel(raw: String): Essence? {
        val s = raw.lowercase()
        val groups = listOf(
            Triple(listOf("plant", "flower", "tree", "leaf", "grass", "food", "fruit"), "VERDANT", "생명"),
            Triple(listOf("electronic", "computer", "phone", "device", "technology", "machine"), "VOLTAIC", "전하"),
            Triple(listOf("book", "paper", "text", "document", "writing"), "ARCHIVAL", "기록"),
            Triple(listOf("water", "drink", "sea", "ocean", "liquid"), "TIDAL", "조석"),
            Triple(listOf("glass", "window", "mirror", "reflection"), "GLASS", "반사"),
            Triple(listOf("metal", "tool", "vehicle", "hardware"), "MECHANICAL", "기계"),
            Triple(listOf("toy", "art", "decoration", "fashion"), "DREAM", "몽상"),
            Triple(listOf("light", "lamp", "fire", "sun"), "EMBER", "잔열")
        )
        val g = groups.firstOrNull { (keys, _, _) -> keys.any { s.contains(it) } } ?: return null
        return Essence(g.second, g.third, raw)
    }

    private fun dominantColorName(bitmap: Bitmap?): Pair<String, String> {
        if (bitmap == null) return "NOCTURNE" to "암흑"
        var r = 0L; var g = 0L; var b = 0L; var n = 0L
        val stepX = (bitmap.width / 24).coerceAtLeast(1)
        val stepY = (bitmap.height / 24).coerceAtLeast(1)
        var y = 0
        while (y < bitmap.height) {
            var x = 0
            while (x < bitmap.width) {
                val c = bitmap.getPixel(x, y)
                r += android.graphics.Color.red(c)
                g += android.graphics.Color.green(c)
                b += android.graphics.Color.blue(c)
                n++
                x += stepX
            }
            y += stepY
        }
        if (n == 0L) return "NOCTURNE" to "암흑"
        val rr = r / n; val gg = g / n; val bb = b / n
        return when {
            rr < 70 && gg < 70 && bb < 70 -> "NOCTURNE" to "암흑"
            gg.toDouble() > rr.toDouble() * 1.15 && gg.toDouble() > bb.toDouble() * 1.08 -> "VERDANT" to "녹색"
            bb.toDouble() > rr.toDouble() * 1.15 && bb.toDouble() > gg.toDouble() * 1.05 -> "TIDAL" to "청색"
            rr.toDouble() > gg.toDouble() * 1.18 && rr.toDouble() > bb.toDouble() * 1.15 -> "EMBER" to "적색"
            rr > 150 && bb > 145 && abs(rr - bb) < 45 -> "DREAM" to "자홍"
            rr > 170 && gg > 170 && bb > 170 -> "GLASS" to "백광"
            else -> "ARCHIVAL" to "중성"
        }
    }

    fun transmute(context: Context, essence: Essence): Relic {
        val all = relics(context)
        val anomaly = todayAnomaly(context)
        val rnd = Random(System.nanoTime() xor System.currentTimeMillis())
        val boosted = essence.code == anomaly.boostTag
        val roll = rnd.nextDouble()
        val rarity = if (boosted) {
            when {
                roll < .008 -> "???"
                roll < .038 -> "FORBIDDEN"
                roll < .115 -> "RELIC"
                roll < .275 -> "ANOMALOUS"
                roll < .535 -> "RARE"
                roll < .80 -> "ODD"
                else -> "NORMAL"
            }
        } else {
            when {
                roll < .005 -> "???"
                roll < .025 -> "FORBIDDEN"
                roll < .08 -> "RELIC"
                roll < .20 -> "ANOMALOUS"
                roll < .42 -> "RARE"
                roll < .72 -> "ODD"
                else -> "NORMAL"
            }
        }
        val pool = all.filter { it.rarity == rarity }
        val weighted = pool.flatMap { relic ->
            val weight = 1 + (if (relic.tags.contains(essence.code)) 4 else 0) +
                (if (relic.tags.contains(anomaly.boostTag)) 2 else 0)
            List(weight) { relic }
        }
        return (weighted.ifEmpty { pool }).random(rnd)
    }

    fun fuse(context: Context, selected: List<Relic>): FusionOutcome {
        require(selected.size == 3)
        val ids = selected.map { it.id }.sorted()
        val secret = recipes(context).firstOrNull { it.requires.sorted() == ids }
        if (secret != null) {
            val result = relics(context).first { it.id == secret.result }
            return FusionOutcome(result, secret.name, "봉인식이 해제되었습니다. 일반 합성표 밖의 결과입니다.")
        }

        val all = relics(context)
        val tags = selected.flatMap { it.tags }
        val highest = selected.maxOf { rarityScore(it.rarity) }
        val rnd = Random(System.nanoTime())
        val candidates = all.filter { candidate ->
            val overlap = candidate.tags.count { it in tags }
            overlap >= 2 && rarityScore(candidate.rarity) <= (highest + 1).coerceAtMost(6)
        }
        val pick = (candidates.ifEmpty { all }).random(rnd)
        return FusionOutcome(pick, null, "세 유물의 공통 계보가 재배열되어 새 기록이 열렸습니다.")
    }

    private fun rarityScore(r: String): Int = when (r) {
        "NORMAL" -> 0; "ODD" -> 1; "RARE" -> 2; "ANOMALOUS" -> 3
        "RELIC" -> 4; "FORBIDDEN" -> 5; else -> 6
    }
}
