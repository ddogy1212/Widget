package com.relic.alchemy.widget

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.*
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.relic.alchemy.MainActivity
import com.relic.alchemy.RelicRepository

class RelicWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Responsive(
        setOf(DpSize(110.dp, 110.dp), DpSize(150.dp, 150.dp), DpSize(180.dp, 180.dp))
    )

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val anomaly = RelicRepository.todayAnomaly(context)
        val count = RelicRepository.discoveredIds(context).size
        val energy = RelicRepository.energy(context)
        val fragments = RelicRepository.fragments(context)
        val (zone, enemy) = RelicRepository.currentRift(context)
        val latestId = RelicRepository.latestId(context)
        val latest = RelicRepository.relics(context).firstOrNull { it.id == latestId }
        val latestBitmap = latest?.let { RelicRepository.bitmap(context, it) }

        provideContent {
            WidgetContent(
                anomaly = anomaly.name,
                count = count,
                energy = energy,
                fragments = fragments,
                zoneName = zone.name,
                zoneCode = zone.code,
                enemyName = enemy.name,
                boss = enemy.boss,
                latestName = latest?.name,
                bitmap = latestBitmap
            )
        }
    }

    @Composable
    private fun WidgetContent(
        anomaly: String,
        count: Int,
        energy: Int,
        fragments: Int,
        zoneName: String,
        zoneCode: String,
        enemyName: String,
        boss: Boolean,
        latestName: String?,
        bitmap: Bitmap?
    ) {
        val width = LocalSize.current.width
        val tiny = width < 130.dp
        val roomy = width >= 155.dp
        val tabKey = ActionParameters.Key<Int>("tab")
        val riftAction = actionStartActivity<MainActivity>(actionParametersOf(tabKey to 0))
        val transmuteAction = actionStartActivity<MainActivity>(actionParametersOf(tabKey to 1))
        val codexAction = actionStartActivity<MainActivity>(actionParametersOf(tabKey to 2))

        Column(
            GlanceModifier.fillMaxSize()
                .background(ColorProvider(Color(0xFF10141F)))
                .cornerRadius(24.dp)
                .padding(if (tiny) 9.dp else 11.dp),
            verticalAlignment = Alignment.Vertical.CenterVertically
        ) {
            Row(GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.Vertical.CenterVertically) {
                Column(GlanceModifier.defaultWeight()) {
                    Text(
                        "RE:LIC",
                        style = TextStyle(color = ColorProvider(Color.White), fontSize = if (tiny) 13.sp else 15.sp, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        if (boss) "⚠ CORE RIFT" else "RIFT ACTIVE",
                        style = TextStyle(color = ColorProvider(if (boss) Color(0xFFFF617C) else Color(0xFFA878FF)), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    )
                }
                Text(
                    "$fragments◇",
                    style = TextStyle(color = ColorProvider(Color(0xFFFFC76B)), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                )
            }

            Spacer(GlanceModifier.height(6.dp))

            Row(GlanceModifier.fillMaxWidth().defaultWeight(), verticalAlignment = Alignment.Vertical.CenterVertically) {
                if (bitmap != null && !tiny) {
                    Image(
                        ImageProvider(bitmap),
                        contentDescription = "최근 유물",
                        modifier = GlanceModifier.size(if (roomy) 58.dp else 48.dp),
                        contentScale = ContentScale.Fit
                    )
                    Spacer(GlanceModifier.width(7.dp))
                }
                Column(GlanceModifier.defaultWeight()) {
                    Text(
                        "$zoneCode · $zoneName",
                        maxLines = 1,
                        style = TextStyle(color = ColorProvider(Color(0xFFB5C0D1)), fontSize = if (tiny) 8.sp else 9.sp, fontWeight = FontWeight.Medium)
                    )
                    Text(
                        enemyName,
                        maxLines = 2,
                        style = TextStyle(color = ColorProvider(Color.White), fontSize = if (tiny) 10.sp else 11.sp, fontWeight = FontWeight.Bold)
                    )
                    if (roomy) {
                        Text(
                            "이상현상 · $anomaly",
                            maxLines = 1,
                            style = TextStyle(color = ColorProvider(Color(0xFF7F8BA0)), fontSize = 8.sp)
                        )
                        Text(
                            "최근 ${latestName ?: "미기록"}  ·  $count/1000",
                            maxLines = 1,
                            style = TextStyle(color = ColorProvider(Color(0xFF7F8BA0)), fontSize = 8.sp)
                        )
                    }
                }
            }

            Spacer(GlanceModifier.height(5.dp))

            if (roomy) {
                Row(GlanceModifier.fillMaxWidth()) {
                    Box(
                        GlanceModifier.defaultWeight().height(30.dp)
                            .background(ColorProvider(if (boss) Color(0xFFB83C58) else Color(0xFF7250CF)))
                            .cornerRadius(14.dp).clickable(riftAction),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("◎ 진입", style = TextStyle(color = ColorProvider(Color.White), fontSize = 10.sp, fontWeight = FontWeight.Bold))
                    }
                    Spacer(GlanceModifier.width(6.dp))
                    Box(
                        GlanceModifier.defaultWeight().height(30.dp)
                            .background(ColorProvider(Color(0xFF242B3C)))
                            .cornerRadius(14.dp).clickable(transmuteAction),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("◈ 연성 $energy/3", style = TextStyle(color = ColorProvider(Color(0xFFD7DDEA)), fontSize = 9.sp, fontWeight = FontWeight.Bold))
                    }
                }
            } else {
                Box(
                    GlanceModifier.fillMaxWidth().height(if (tiny) 26.dp else 29.dp)
                        .background(ColorProvider(if (boss) Color(0xFFB83C58) else Color(0xFF7250CF)))
                        .cornerRadius(14.dp).clickable(riftAction),
                    contentAlignment = Alignment.Center
                ) {
                    Text("◎ 균열 진입", style = TextStyle(color = ColorProvider(Color.White), fontSize = if (tiny) 9.sp else 10.sp, fontWeight = FontWeight.Bold))
                }
            }
        }
    }
}

class RelicWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = RelicWidget()
}
