package com.relic.alchemy.widget

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.cornerRadius
import androidx.glance.background
import androidx.glance.unit.ColorProvider
import androidx.glance.layout.*
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import com.relic.alchemy.MainActivity
import com.relic.alchemy.RelicRepository

class RelicWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Responsive(
        setOf(DpSize(110.dp, 110.dp), DpSize(150.dp, 150.dp), DpSize(180.dp, 180.dp))
    )

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val anomaly = RelicRepository.todayAnomaly(context)
        val count = RelicRepository.discoveredIds(context).size
        val energy = RelicRepository.energy(context)
        val latestId = RelicRepository.latestId(context)
        val latest = RelicRepository.relics(context).firstOrNull { it.id == latestId }
        val latestBitmap = latest?.let { RelicRepository.bitmap(context, it) }

        provideContent {
            WidgetContent(
                anomaly = anomaly.name,
                count = count,
                energy = energy,
                latestName = latest?.name,
                rarity = latest?.rarity,
                bitmap = latestBitmap
            )
        }
    }

    @Composable
    private fun WidgetContent(
        anomaly: String,
        count: Int,
        energy: Int,
        latestName: String?,
        rarity: String?,
        bitmap: Bitmap?
    ) {
        val width = LocalSize.current.width
        val tiny = width < 130.dp
        val roomy = width >= 155.dp
        val tabKey = ActionParameters.Key<Int>("tab")
        val transmuteAction = actionStartActivity<MainActivity>(actionParametersOf(tabKey to 0))
        val codexAction = actionStartActivity<MainActivity>(actionParametersOf(tabKey to 1))

        Column(
            GlanceModifier.fillMaxSize()
                .background(ColorProvider(Color(0xFF111522)))
                .cornerRadius(24.dp)
                .padding(if (tiny) 9.dp else 11.dp)
                .clickable(transmuteAction),
            verticalAlignment = Alignment.Vertical.CenterVertically
        ) {
            Row(GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.Vertical.CenterVertically) {
                Column(GlanceModifier.defaultWeight()) {
                    Text(
                        "RE:LIC",
                        style = TextStyle(
                            color = ColorProvider(Color.White),
                            fontSize = if (tiny) 13.sp else 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        anomaly,
                        maxLines = 1,
                        style = TextStyle(
                            color = ColorProvider(Color(0xFFA878FF)),
                            fontSize = if (tiny) 8.sp else 9.sp,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
                Text(
                    "$energy/3",
                    style = TextStyle(
                        color = ColorProvider(Color(0xFFFFC76B)),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(GlanceModifier.height(6.dp))

            Row(
                GlanceModifier.fillMaxWidth().defaultWeight(),
                verticalAlignment = Alignment.Vertical.CenterVertically
            ) {
                if (bitmap != null) {
                    Image(
                        ImageProvider(bitmap),
                        contentDescription = "최근 유물",
                        modifier = GlanceModifier.size(if (tiny) 48.dp else if (roomy) 66.dp else 56.dp),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Box(
                        GlanceModifier.size(if (tiny) 48.dp else 56.dp)
                            .background(ColorProvider(Color(0xFF1C2333)))
                            .cornerRadius(15.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "◈",
                            style = TextStyle(color = ColorProvider(Color(0xFFA878FF)), fontSize = 22.sp)
                        )
                    }
                }

                Spacer(GlanceModifier.width(7.dp))

                Column(GlanceModifier.defaultWeight()) {
                    Text(
                        latestName ?: "첫 유물을 호출하세요",
                        maxLines = 2,
                        style = TextStyle(
                            color = ColorProvider(Color.White),
                            fontSize = if (tiny) 9.sp else 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    if (!tiny) {
                        Text(
                            rarity ?: "UNRECORDED",
                            style = TextStyle(color = ColorProvider(Color(0xFF9EA9BC)), fontSize = 8.sp)
                        )
                    }
                    Text(
                        "도감 $count/1000",
                        style = TextStyle(color = ColorProvider(Color(0xFF9EA9BC)), fontSize = 8.sp)
                    )
                }
            }

            Spacer(GlanceModifier.height(5.dp))

            if (roomy) {
                Row(GlanceModifier.fillMaxWidth()) {
                    Box(
                        GlanceModifier.defaultWeight().height(30.dp)
                            .background(ColorProvider(Color(0xFFA878FF)))
                            .cornerRadius(14.dp)
                            .clickable(transmuteAction),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("◉ 연성", style = TextStyle(color = ColorProvider(Color.White), fontSize = 10.sp, fontWeight = FontWeight.Bold))
                    }
                    Spacer(GlanceModifier.width(6.dp))
                    Box(
                        GlanceModifier.defaultWeight().height(30.dp)
                            .background(ColorProvider(Color(0xFF242B3C)))
                            .cornerRadius(14.dp)
                            .clickable(codexAction),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("▦ 도감", style = TextStyle(color = ColorProvider(Color(0xFFD7DDEA)), fontSize = 10.sp, fontWeight = FontWeight.Bold))
                    }
                }
            } else {
                Box(
                    GlanceModifier.fillMaxWidth().height(if (tiny) 26.dp else 29.dp)
                        .background(ColorProvider(Color(0xFFA878FF)))
                        .cornerRadius(14.dp)
                        .clickable(transmuteAction),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "◉ 연성하기",
                        style = TextStyle(
                            color = ColorProvider(Color.White),
                            fontSize = if (tiny) 9.sp else 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }
    }
}

class RelicWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = RelicWidget()
}
